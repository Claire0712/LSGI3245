-- Prerequisite: import HKDistrict18.shp into public.hk_admin_raw.
-- The supplied shapefile is WGS 84 (EPSG:4326) and contains 18 records.

TRUNCATE TABLE public.hk_admin RESTART IDENTITY CASCADE;

INSERT INTO public.hk_admin (district_name, district_name_zh, geom)
SELECT
    CASE upper(trim(ename))
        WHEN 'CENTRAL & WESTERN' THEN 'Central and Western'
        WHEN 'WAN CHAI' THEN 'Wan Chai'
        WHEN 'EASTERN' THEN 'Eastern'
        WHEN 'SOUTHERN' THEN 'Southern'
        WHEN 'YAU TSIM MONG' THEN 'Yau Tsim Mong'
        WHEN 'SHAM SHUI PO' THEN 'Sham Shui Po'
        WHEN 'KOWLOON CITY' THEN 'Kowloon City'
        WHEN 'WONG TAI SIN' THEN 'Wong Tai Sin'
        WHEN 'KWUN TONG' THEN 'Kwun Tong'
        WHEN 'KWAI TSING' THEN 'Kwai Tsing'
        WHEN 'TSUEN WAN' THEN 'Tsuen Wan'
        WHEN 'TUEN MUN' THEN 'Tuen Mun'
        WHEN 'YUEN LONG' THEN 'Yuen Long'
        WHEN 'NORTH' THEN 'North'
        WHEN 'TAI PO' THEN 'Tai Po'
        WHEN 'SHA TIN' THEN 'Sha Tin'
        WHEN 'SAI KUNG' THEN 'Sai Kung'
        WHEN 'ISLANDS' THEN 'Islands'
        ELSE initcap(lower(trim(ename)))
    END AS district_name,
    trim(cname) AS district_name_zh,
    ST_Multi(
        ST_CollectionExtract(
            ST_MakeValid(ST_SetSRID(geom, 4326)),
            3
        )
    )::geometry(MultiPolygon, 4326) AS geom
FROM public.hk_admin_raw;

DO $$
DECLARE
    district_count integer;
    invalid_count integer;
BEGIN
    SELECT count(*) INTO district_count FROM public.hk_admin;
    SELECT count(*) INTO invalid_count
    FROM public.hk_admin
    WHERE NOT ST_IsValid(geom) OR ST_IsEmpty(geom) OR ST_SRID(geom) <> 4326;

    IF district_count <> 18 THEN
        RAISE EXCEPTION 'Expected 18 districts, found %', district_count;
    END IF;

    IF invalid_count <> 0 THEN
        RAISE EXCEPTION 'Found % invalid/empty/wrong-SRID district geometries', invalid_count;
    END IF;
END $$;
