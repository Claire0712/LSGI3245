-- Run this file only after B has created and populated public.facilities.

-- 1. Every valid facility point should be covered by one administrative district.
SELECT count(*) AS unmatched_facility_count
FROM public.facilities AS f
WHERE NOT EXISTS (
    SELECT 1
    FROM public.hk_admin AS a
    WHERE ST_Covers(a.geom, f.geom)
);

-- 2. Sample three-table join supporting per-capita analysis.
SELECT
    a.district_name,
    c.population,
    count(f.facility_id) AS facility_count,
    round(count(f.facility_id) * 100000.0 / NULLIF(c.population, 0), 3)
        AS facilities_per_100000_people
FROM public.hk_admin AS a
JOIN public.census AS c
  ON c.district_name = a.district_name
LEFT JOIN public.facilities AS f
  ON ST_Covers(a.geom, f.geom)
GROUP BY a.district_name, c.population
ORDER BY facilities_per_100000_people DESC;
