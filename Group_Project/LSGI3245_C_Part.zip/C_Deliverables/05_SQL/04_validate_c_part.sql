-- 1. Basic record-count and population checks.
SELECT count(*) AS hk_admin_rows FROM public.hk_admin;
SELECT count(*) AS census_rows FROM public.census;

SELECT
    sum(population) AS population_total,
    round(sum(population_percentage), 6) AS percentage_total
FROM public.census;

-- Expected: population_total = 7411945; percentage_total approximately 100.

-- 2. Names in HK_Admin but not in census. Expected: zero rows.
SELECT district_name
FROM public.hk_admin
EXCEPT
SELECT district_name
FROM public.census;

-- 3. Names in census but not in HK_Admin. Expected: zero rows.
SELECT district_name
FROM public.census
EXCEPT
SELECT district_name
FROM public.hk_admin;

-- 4. Geometry checks. Expected: 18 valid MultiPolygons with SRID 4326.
SELECT
    count(*) AS district_count,
    count(*) FILTER (WHERE ST_IsValid(geom)) AS valid_geometry_count,
    count(*) FILTER (WHERE ST_GeometryType(geom) = 'ST_MultiPolygon') AS multipolygon_count,
    count(*) FILTER (WHERE ST_SRID(geom) = 4326) AS srid_4326_count
FROM public.hk_admin;

-- These C-part-only checks do not require B's Facilities table.
