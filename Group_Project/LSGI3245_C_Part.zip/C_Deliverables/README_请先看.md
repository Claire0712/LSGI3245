# LSGI3245 C 部分数据说明

## 已完成内容

1. 清洗 Fitness Rooms 和 Sports Grounds 数据。
2. 建立 `HK_Admin` 和 `census` 的标准字段及导入脚本。
3. 统一十八区英文名称，确保 `HK_Admin.district_name` 与
   `census.district_name` 可以直接连接。
4. 完成三张表的 schema diagram。
5. 使用十八区边界检查设施坐标与行政区是否一致。

## 最终数据结果

- Fitness Rooms：86 条唯一记录。
- Sports Grounds：25 条记录。
- C 部分设施合计：111 条。
- 行政区：18 个，WGS 84 / EPSG:4326。
- Census：18 个行政区，2021 年陆地总人口 7,411,945。
- 坐标空间检查：111 个点均位于对应行政区内。
- 标准化后重复记录：0。

## 发给 B 的文件

只需要发送 `01_交给B/Facilities_C_handoff.csv`。字段顺序为：

```text
facility_type,facility_name,address,latitude,longitude
```

`facility_id` 和 `geom` 由 B 在建立总 `Facilities` 表时生成。

## 三张表的关系

- `Facilities` → `HK_Admin`：空间关系，使用
  `ST_Covers(HK_Admin.geom, Facilities.geom)` 判断设施所属行政区。
- `census` → `HK_Admin`：普通属性关系，使用统一后的
  `district_name` 连接；`census.district_name` 同时是主键和外键。
- `census` 按项目要求不含 geometry 字段。

## 数据年份说明

项目说明建议使用 2016 年人口资料，但课程提供的文件明确属于
2021 Population Census。本部分采用课程提供的 2021 文件，并在
`census_year` 字段及说明文件中明确记录年份，避免把 2021 数据误标为 2016。

## 导入顺序

1. 运行 `03_HK_Admin/import_hk_admin.sh`，导入十八区 shapefile。
2. 脚本依次建立 `HK_Admin`、载入 `census` 并执行基础验证。
3. B 建立并载入总 `Facilities` 表后，运行
   `05_SQL/05_validate_three_table_integration.sql` 检查三表关系。

运行环境需要 PostgreSQL、PostGIS、`psql` 和 `shp2pgsql`。
