#!/usr/bin/env python3
import argparse
import csv
import html
import json
import re
from pathlib import Path

DISTRICT_MAP = {
    "central & western": "Central and Western",
    "central and western": "Central and Western",
    "eastern": "Eastern",
    "islands": "Islands",
    "kowloon city": "Kowloon City",
    "kwai tsing": "Kwai Tsing",
    "kwun tong": "Kwun Tong",
    "north": "North",
    "sai kung": "Sai Kung",
    "sha tin": "Sha Tin",
    "sham shui po": "Sham Shui Po",
    "southern": "Southern",
    "tai po": "Tai Po",
    "tsuen wan": "Tsuen Wan",
    "tuen mun": "Tuen Mun",
    "wan chai": "Wan Chai",
    "wong tai sin": "Wong Tai Sin",
    "yau tsim mong": "Yau Tsim Mong",
    "yuen long": "Yuen Long",
}

OUTPUT_FIELDS = [
    "facility_type",
    "facility_name",
    "address",
    "district_name",
    "latitude",
    "longitude",
]

# Corrections for invalid coordinates in the LCSD fitness-room feed downloaded
# on 2026-11-03. Values are taken from the LCSD Sports Centres dataset for Hiu
# Kwong Street and Tai Po Hui; Sham Shui Po uses the matching government
# building location at 38 Sham Mong Road. Keep these explicit and auditable
# rather than silently accepting impossible source coordinates.
COORDINATE_OVERRIDES = {
    "choi wing road sports centre": (22.32949, 114.21663),
    "hiu kwong street sports centre": (22 + 19 / 60 + 21 / 3600, 114 + 13 / 60 + 14 / 3600),
    "sham shui po sports centre": (22 + 19 / 60 + 50 / 3600, 114 + 8 / 60 + 57 / 3600),
    "tai po hui sports centre": (22 + 27 / 60 + 19 / 3600, 114 + 9 / 60 + 54 / 3600),
    "tung cheong street sports centre": (22 + 26 / 60 + 58.99 / 3600, 114 + 10 / 60 + 12.12 / 3600),
}


def clean_text(value):
    if value is None:
        return ""
    text = html.unescape(str(value))
    text = re.sub(r"<br\s*/?>", " ", text, flags=re.I)
    text = re.sub(r"<[^>]+>", "", text)
    return " ".join(text.split()).strip()


def first(record, *names):
    lowered = {str(k).strip().lower(): v for k, v in record.items()}
    for name in names:
        if name.lower() in lowered and clean_text(lowered[name.lower()]):
            return lowered[name.lower()]
    return ""


def parse_coordinate(value):
    text = clean_text(value)
    if not text:
        raise ValueError("missing coordinate")
    try:
        return float(text)
    except ValueError:
        pass

    parts = [p for p in re.split(r"[^0-9.]+", text) if p]
    if len(parts) != 3:
        raise ValueError(f"unsupported coordinate: {text}")
    degrees, minutes, seconds = map(float, parts)
    if minutes >= 60 or seconds >= 60:
        raise ValueError(f"invalid DMS coordinate: {text}")
    return degrees + minutes / 60 + seconds / 3600


def load_records(path):
    suffix = path.suffix.lower()
    if suffix == ".json":
        data = json.loads(path.read_text(encoding="utf-8-sig"))
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            for key in ("features", "records", "data", "result"):
                candidate = data.get(key)
                if isinstance(candidate, list):
                    if key == "features":
                        return [item.get("properties", item) for item in candidate]
                    return candidate
        raise ValueError("JSON does not contain a record list")
    if suffix == ".csv":
        with path.open("r", encoding="utf-8-sig", newline="") as stream:
            return list(csv.DictReader(stream))
    raise ValueError("Input must be .json or .csv")


def transform(record, facility_type):
    facility_name = clean_text(first(record, "facility_name", "name_en", "name", "ename"))
    address = clean_text(first(record, "address", "address_en", "address_e"))
    district_raw = clean_text(first(record, "district_name", "district_en", "district"))
    district_name = DISTRICT_MAP.get(district_raw.casefold(), district_raw)

    if not facility_name:
        raise ValueError("missing facility name")

    override = COORDINATE_OVERRIDES.get(facility_name.casefold())
    if override is not None:
        latitude, longitude = override
    else:
        latitude = parse_coordinate(first(record, "latitude", "lat"))
        longitude = parse_coordinate(first(record, "longitude", "lng", "lon", "long"))

    if not (22.1 <= latitude <= 22.6 and 113.8 <= longitude <= 114.5):
        raise ValueError(f"coordinate outside Hong Kong bounds: {latitude}, {longitude}")
    if district_name not in set(DISTRICT_MAP.values()):
        raise ValueError(f"unrecognized district: {district_raw}")

    return {
        "facility_type": facility_type,
        "facility_name": facility_name,
        "address": address,
        "district_name": district_name,
        "latitude": f"{latitude:.7f}",
        "longitude": f"{longitude:.7f}",
    }


def write_csv(path, fields, rows):
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("--type", required=True, choices=["Fitness Room", "Sports Ground"])
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    records = load_records(args.input)
    accepted = []
    rejected = []
    seen = set()

    for row_number, record in enumerate(records, start=1):
        try:
            cleaned = transform(record, args.type)
            key = (
                cleaned["facility_type"].casefold(),
                cleaned["facility_name"].casefold(),
                cleaned["address"].casefold(),
                cleaned["latitude"],
                cleaned["longitude"],
            )
            if key in seen:
                raise ValueError("duplicate record")
            seen.add(key)
            accepted.append(cleaned)
        except Exception as error:
            rejected.append({
                "source_row": row_number,
                "reason": str(error),
                "source_record": json.dumps(record, ensure_ascii=False),
            })

    args.output.parent.mkdir(parents=True, exist_ok=True)
    write_csv(args.output, OUTPUT_FIELDS, accepted)
    rejected_path = args.output.with_name(args.output.stem + "_rejected.csv")
    write_csv(rejected_path, ["source_row", "reason", "source_record"], rejected)
    print(f"accepted={len(accepted)} rejected={len(rejected)}")
    print(args.output)
    print(rejected_path)


if __name__ == "__main__":
    main()
