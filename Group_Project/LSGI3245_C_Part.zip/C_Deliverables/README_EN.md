# LSGI3245 C-part data package

## Completed

- Cleaned the supplied 2021 census workbook into 18 district records.
- Calculated each district's percentage of the land total population (7,411,945).
- Inspected the supplied `HKDistrict18` shapefile: 18 records, WGS 84 / EPSG:4326,
  polygon shape type, Hong Kong bounding box.
- Standardized the only material name mismatch:
  `CENTRAL & WESTERN` / `Central and Western` -> `Central and Western`.
- Added SQL to create, populate and validate `HK_Admin` and `census`.
- Cleaned the downloaded LCSD Fitness Rooms and Sports Grounds files.
- Produced 86 unique Fitness Room records and 25 Sports Ground records.
- Corrected five source-coordinate problems and removed one duplicate source row.
- Spatially checked all 111 cleaned points against the supplied 18-district boundary;
  every point falls in its stated district.

The project PDF recommends 2016 data, but the file currently supplied on the
course page is explicitly the **2021 Population Census**. This package uses the
course-supplied 2021 file and records `census_year = 2021`.

## Files

- `01_交给B/Facilities_C_handoff.csv`: 111 records using the exact five-column
  structure agreed for B's `Facilities` import.
- `02_Facilities清洗结果/`: detailed Fitness Room and Sports Ground outputs,
  the rejected duplicate row, and coordinate correction notes.
- `03_HK_Admin/`: the complete `HKDistrict18` shapefile set and import script.
- `04_Census/census_cleaned.csv`: 18 district population records for import.
- `04_Census/census_cleaned.xlsx`: formatted review copy with a district mapping sheet.
- `04_Census/district_name_mapping.csv`: source-to-canonical district name mapping.
- `05_SQL/`: SQL for table creation, data loading, and validation.
- `06_原始数据与清洗脚本/`: the two downloaded LCSD JSON sources and reusable
  cleaning script.
- `schema.md`: three-table relationship diagram.
- `schema_diagram.svg`: ready-to-open visual schema diagram for the presentation.

## Import HK_Admin and census

From the package directory, run:

```bash
sh 03_HK_Admin/import_hk_admin.sh \
  03_HK_Admin/HKDistrict18.shp database_name
```

Requirements: PostgreSQL, PostGIS, `psql`, and `shp2pgsql`.

## Clean the two facility datasets

After obtaining the original files from LCSD/CSDI:

```bash
python3 06_原始数据与清洗脚本/clean_facilities.py \
  06_原始数据与清洗脚本/facility-fitrm.json \
  --type "Fitness Room" --output Fitness_Rooms_cleaned.csv

python3 06_原始数据与清洗脚本/clean_facilities.py \
  06_原始数据与清洗脚本/facility-sg.json \
  --type "Sports Ground" --output Sports_Grounds_cleaned.csv
```

The two detailed cleaned files retain `district_name` for C's spatial audit:

```text
facility_type,facility_name,address,district_name,latitude,longitude
```

The file to send to B is `Facilities_C_handoff.csv`, with exactly:

```text
facility_type,facility_name,address,latitude,longitude
```

`facility_id` and `geom` should be created by B when importing all eight facility
types into `Facilities`.

## Validation result

- Census: 18 districts; land total population 7,411,945; percentage total 100%.
- HK_Admin: 18 polygon records; WGS 84 / EPSG:4326.
- Facilities completed by C: 111 unique points across all 18 districts.
- Spatial district mismatches after correction: 0.
- Duplicate standardized facility rows after cleaning: 0.
