#!/bin/sh
set -eu

if [ "$#" -ne 2 ]; then
    echo "Usage: $0 /path/to/HKDistrict18.shp database_name" >&2
    exit 1
fi

shapefile_path=$1
database_name=$2

if [ ! -f "$shapefile_path" ]; then
    echo "Shapefile not found: $shapefile_path" >&2
    exit 1
fi

script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
sql_dir="$script_dir/../05_SQL"

psql -v ON_ERROR_STOP=1 -d "$database_name" \
    -c 'DROP TABLE IF EXISTS public.hk_admin_raw;'

shp2pgsql -D -I -s 4326 -W UTF-8 \
    "$shapefile_path" public.hk_admin_raw \
    | psql -v ON_ERROR_STOP=1 -d "$database_name"

psql -v ON_ERROR_STOP=1 -d "$database_name" \
    -f "$sql_dir/01_create_c_tables.sql"

psql -v ON_ERROR_STOP=1 -d "$database_name" \
    -f "$sql_dir/02_build_hk_admin_from_staging.sql"

psql -v ON_ERROR_STOP=1 -d "$database_name" \
    -f "$sql_dir/03_load_census.sql"

psql -v ON_ERROR_STOP=1 -d "$database_name" \
    -f "$sql_dir/04_validate_c_part.sql"
