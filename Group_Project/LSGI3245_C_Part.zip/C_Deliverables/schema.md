# C-part database schema

```mermaid
erDiagram
    FACILITIES {
        bigint facility_id PK
        varchar facility_type
        varchar facility_name
        varchar address
        double_precision latitude
        double_precision longitude
        geometry_Point_4326 geom
    }

    HK_ADMIN {
        smallint district_id PK
        varchar district_name UK
        varchar district_name_zh
        geometry_MultiPolygon_4326 geom
    }

    CENSUS {
        varchar district_name PK,FK
        integer population
        numeric population_percentage
        smallint census_year
    }

    HK_ADMIN ||--|| CENSUS : "district_name"
    HK_ADMIN ||--o{ FACILITIES : "ST_Covers(admin.geom, facility.geom)"
```

`Facilities` and `HK_Admin` are spatially related. `HK_Admin` and `census`
use a normal attribute join on the standardized `district_name`.
