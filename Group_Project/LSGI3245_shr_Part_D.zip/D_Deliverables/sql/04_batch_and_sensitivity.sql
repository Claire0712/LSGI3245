-- LEFT JOIN LATERAL preserves the input point even if the facility table is empty.
SELECT q.location_id,q.label,q.longitude,q.latitude,n.facility_id,n.facility_name,
       n.facility_type,n.district,round(n.distance_m::numeric,3) AS distance_m
FROM d_project.query_locations q
LEFT JOIN LATERAL d_project.nearest_facility(q.longitude,q.latitude) n ON true
ORDER BY q.location_id;

SELECT q.location_id,q.label,500 AS radius_m,s.facility_count,s.type_count,s.facility_types
FROM d_project.query_locations q
CROSS JOIN LATERAL d_project.nearby_summary(q.longitude,q.latitude,500) s
ORDER BY q.location_id;

-- Sensitivity check; this does not replace the project's two additional research questions.
SELECT q.location_id,q.label,r.radius_m,s.facility_count,s.type_count,s.facility_types
FROM d_project.query_locations q
CROSS JOIN (VALUES(400),(500),(800)) r(radius_m)
CROSS JOIN LATERAL d_project.nearby_summary(q.longitude,q.latitude,r.radius_m) s
ORDER BY q.location_id,r.radius_m;

-- Data coverage must contain all eight types before interpreting group-wide results.
SELECT facility_type,count(*) AS facility_count
FROM d_project.facilities_input GROUP BY facility_type ORDER BY facility_type;

-- The planner may prefer a sequential scan for a small table; that is not a defect.
EXPLAIN (ANALYZE,BUFFERS)
SELECT facility_id FROM d_project.facilities_input
WHERE ST_DWithin(geom::geography,
    ST_SetSRID(ST_MakePoint(114.1795,22.3048),4326)::geography,500,true);
