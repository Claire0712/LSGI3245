-- Run after 00, 01 and 02. All fixture changes are rolled back.
-- Run this in a separate session; do not edit the input view concurrently.
BEGIN;
CREATE TABLE d_project.qa_fixture (
    facility_id text,facility_name text,facility_type text,district text,address text,
    geom geometry(Point,4326)
);
INSERT INTO d_project.qa_fixture VALUES
 ('a','Fixture A','Badminton Courts','Test district','',ST_SetSRID(ST_MakePoint(114,22),4326)),
 ('b','Fixture B','Fitness Rooms','Test district','',ST_SetSRID(ST_MakePoint(114,22),4326)),
 ('c','Fixture C','Badminton Courts','Test district','',
  ST_Project(ST_SetSRID(ST_MakePoint(114,22),4326)::geography,500,pi()/2)::geometry);

CREATE OR REPLACE VIEW d_project.facilities_input AS
SELECT facility_id,facility_name,facility_type,district,address,geom FROM d_project.qa_fixture;

DO $$
DECLARE n record; s record; boundary_m double precision; rejected boolean;
BEGIN
    SELECT * INTO n FROM d_project.nearest_facility(114,22);
    IF n.facility_id <> 'a' OR abs(n.distance_m) > 0.00001 THEN
        RAISE EXCEPTION 'FAIL: zero distance or deterministic tie breaking';
    END IF;
    SELECT * INTO s FROM d_project.nearby_summary(114,22,0);
    IF s.facility_count <> 2 OR s.type_count <> 2 THEN
        RAISE EXCEPTION 'FAIL: co-located facilities at zero radius';
    END IF;
    SELECT ST_Distance(geom::geography,d_project.query_point(114,22),true)
    INTO boundary_m FROM d_project.qa_fixture WHERE facility_id='c';
    SELECT * INTO s FROM d_project.nearby_summary(114,22,boundary_m+0.01);
    IF s.facility_count <> 3 OR s.type_count <> 2 THEN
        RAISE EXCEPTION 'FAIL: duplicate types must count only once';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM d_project.nearby_facilities(114,22,boundary_m) WHERE facility_id='c') THEN
        RAISE EXCEPTION 'FAIL: exact distance boundary must be inclusive';
    END IF;
    IF EXISTS (SELECT 1 FROM d_project.nearby_facilities(114,22,boundary_m-0.01) WHERE facility_id='c') THEN
        RAISE EXCEPTION 'FAIL: point outside radius was included';
    END IF;
    SELECT * INTO s FROM d_project.nearby_summary(0,0,1);
    IF s.facility_count <> 0 OR s.type_count <> 0 OR cardinality(s.facility_types) <> 0 THEN
        RAISE EXCEPTION 'FAIL: no-match summary must contain zeros and an empty array';
    END IF;
    rejected := false;
    BEGIN
        PERFORM * FROM d_project.nearby_summary(114,22,-1);
    EXCEPTION WHEN raise_exception THEN rejected := true; END;
    IF NOT rejected THEN RAISE EXCEPTION 'FAIL: negative radius accepted'; END IF;
    rejected := false;
    BEGIN
        PERFORM * FROM d_project.nearest_facility(22,114);
    EXCEPTION WHEN raise_exception THEN rejected := true; END;
    IF NOT rejected THEN RAISE EXCEPTION 'FAIL: swapped coordinates accepted'; END IF;
    rejected := false;
    BEGIN
        PERFORM * FROM d_project.nearest_facility(NULL,22);
    EXCEPTION WHEN raise_exception THEN rejected := true; END;
    IF NOT rejected THEN RAISE EXCEPTION 'FAIL: null longitude accepted'; END IF;
    rejected := false;
    BEGIN
        PERFORM * FROM d_project.nearby_summary(114,22,'NaN'::double precision);
    EXCEPTION WHEN raise_exception THEN rejected := true; END;
    IF NOT rejected THEN RAISE EXCEPTION 'FAIL: non-finite radius accepted'; END IF;
    DELETE FROM d_project.qa_fixture;
    IF EXISTS (SELECT 1 FROM d_project.nearest_facility(114,22)) THEN
        RAISE EXCEPTION 'FAIL: empty input must not invent a nearest facility';
    END IF;
    SELECT * INTO s FROM d_project.nearby_summary(114,22,500);
    IF s.facility_count <> 0 OR s.type_count <> 0 THEN
        RAISE EXCEPTION 'FAIL: empty input summary';
    END IF;
    RAISE NOTICE 'PASS: all 11 regression scenarios';
END;
$$;
ROLLBACK;
