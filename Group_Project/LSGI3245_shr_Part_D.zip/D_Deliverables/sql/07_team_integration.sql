-- OPTIONAL: Do not run until the team has agreed its field names and all eight types.
-- The executable default uses the audited demonstration snapshot.
-- Replace only the facilities_input view to connect the same functions to the team data.
-- Adapt identifiers in the commented example to the actual schema first.
-- Unquoted Facilities is stored as facilities by PostgreSQL. A quoted mixed-case
-- table must instead be referenced as public."Facilities".

/*
CREATE OR REPLACE VIEW d_project.facilities_input AS
SELECT facility_id::text AS facility_id,
       facility_name::text AS facility_name,
       facility_type::text AS facility_type,
       district::text AS district,
       address::text AS address,
       ST_Transform(geom,4326)::geometry(Point,4326) AS geom
FROM public.facilities;

-- After checking the team's geometry SRID and constraints, the team can add:
CREATE INDEX facilities_team_geography_gix ON public.facilities
USING gist ((ST_Transform(geom,4326)::geography));
*/

-- Required interface checks; fix input errors rather than silently filtering rows.
SELECT facility_type,count(*) FROM d_project.facilities_input
GROUP BY facility_type ORDER BY facility_type;
SELECT facility_id,count(*) FROM d_project.facilities_input
GROUP BY facility_id HAVING count(*)>1;
SELECT facility_id FROM d_project.facilities_input
WHERE facility_id IS NULL OR facility_type IS NULL OR facility_name IS NULL
   OR geom IS NULL OR ST_IsEmpty(geom) OR NOT ST_IsValid(geom)
   OR ST_SRID(geom)<>4326 OR GeometryType(geom)<>'POINT';

-- D's cleaned contribution for B: data/facilities_D.csv (149 rows).
-- The other six types in this package are a reproducible validation snapshot.
-- Do not append those six types again if the team has already imported them.
