-- Compare PostGIS outputs against independently computed WGS84/PROJ results.
-- Run against the bundled snapshot; a different team snapshot may legitimately differ.
BEGIN;
CREATE TEMP TABLE expected_nearest (location_id text,facility_id text,distance_m double precision) ON COMMIT DROP;
INSERT INTO expected_nearest VALUES
('Q01','basketball:297',432.969),
('Q02','fitness:36',504.675),
('Q03','parks:41',194.799),
('Q04','swimming:6',257.595);
CREATE TEMP TABLE expected_radius (location_id text,radius_m integer,facility_count bigint,type_count bigint) ON COMMIT DROP;
INSERT INTO expected_radius VALUES
('Q01',400,0,0),
('Q01',500,1,1),
('Q01',800,3,1),
('Q02',400,0,0),
('Q02',500,0,0),
('Q02',800,10,4),
('Q03',400,1,1),
('Q03',500,5,4),
('Q03',800,9,6),
('Q04',400,5,4),
('Q04',500,5,4),
('Q04',800,6,5);
DO $$
BEGIN
 IF (SELECT count(*) FROM d_project.facilities_input) <> 775 OR
    (SELECT count(DISTINCT facility_type) FROM d_project.facilities_input) <> 8 THEN
   RAISE EXCEPTION 'FAIL: reference tests require the bundled 775-row, eight-type snapshot';
 END IF;
 IF EXISTS (
   SELECT 1 FROM expected_nearest e
   JOIN d_project.query_locations q USING(location_id)
   LEFT JOIN LATERAL d_project.nearest_facility(q.longitude,q.latitude) n ON true
   WHERE n.facility_id IS DISTINCT FROM e.facility_id OR abs(n.distance_m-e.distance_m)>0.002
 ) THEN RAISE EXCEPTION 'FAIL: nearest result differs from independent reference'; END IF;
 IF EXISTS (
   SELECT 1 FROM expected_radius e
   JOIN d_project.query_locations q USING(location_id)
   CROSS JOIN LATERAL d_project.nearby_summary(q.longitude,q.latitude,e.radius_m) s
   WHERE s.facility_count<>e.facility_count OR s.type_count<>e.type_count
 ) THEN RAISE EXCEPTION 'FAIL: radius counts differ from independent reference'; END IF;
 RAISE NOTICE 'PASS: four nearest results and twelve radius scenarios match the independent reference';
END;
$$;
COMMIT;
