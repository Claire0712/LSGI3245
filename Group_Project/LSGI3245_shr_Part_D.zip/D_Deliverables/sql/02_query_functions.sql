-- Longitude is X; latitude is Y. Geography distances are measured in metres.
CREATE OR REPLACE FUNCTION d_project.query_point(lon double precision, lat double precision)
RETURNS geography LANGUAGE plpgsql IMMUTABLE AS $$
BEGIN
    IF lon IS NULL OR lat IS NULL OR NOT (lon BETWEEN -180 AND 180)
       OR NOT (lat BETWEEN -90 AND 90) THEN
        RAISE EXCEPTION 'Longitude and latitude must be finite, non-null and in valid ranges';
    END IF;
    RETURN ST_SetSRID(ST_MakePoint(lon,lat),4326)::geography;
END;
$$;

CREATE OR REPLACE FUNCTION d_project.nearest_facility(lon double precision, lat double precision)
RETURNS TABLE(facility_id text, facility_name text, facility_type text,
              district text, address text, distance_m double precision)
LANGUAGE plpgsql STABLE AS $$
DECLARE p geography := d_project.query_point(lon,lat);
BEGIN
    -- Exact spheroidal ordering across the full input; the ID resolves exact ties.
    -- Deliberately avoid approximate KNN shortlists that could miss the true minimum.
    RETURN QUERY
    SELECT f.facility_id,f.facility_name,f.facility_type,f.district,f.address,
           ST_Distance(f.geom::geography,p,true) AS distance_m
    FROM d_project.facilities_input AS f
    ORDER BY ST_Distance(f.geom::geography,p,true),f.facility_id COLLATE "C"
    LIMIT 1;
END;
$$;

CREATE OR REPLACE FUNCTION d_project.nearby_facilities(
    lon double precision, lat double precision, radius_m double precision DEFAULT 500)
RETURNS TABLE(facility_id text, facility_name text, facility_type text,
              district text, address text, distance_m double precision)
LANGUAGE plpgsql STABLE AS $$
DECLARE p geography := d_project.query_point(lon,lat);
BEGIN
    IF radius_m IS NULL OR NOT (radius_m >= 0 AND radius_m < 'Infinity'::double precision) THEN
        RAISE EXCEPTION 'Radius must be finite, non-null and non-negative';
    END IF;
    RETURN QUERY
    SELECT f.facility_id,f.facility_name,f.facility_type,f.district,f.address,
           ST_Distance(f.geom::geography,p,true)
    FROM d_project.facilities_input AS f
    WHERE ST_DWithin(f.geom::geography,p,radius_m,true)
    ORDER BY ST_Distance(f.geom::geography,p,true),f.facility_id COLLATE "C";
END;
$$;

CREATE OR REPLACE FUNCTION d_project.nearby_summary(
    lon double precision, lat double precision, radius_m double precision DEFAULT 500)
RETURNS TABLE(facility_count bigint,type_count bigint,facility_types text[])
LANGUAGE sql STABLE AS $$
    SELECT count(*),count(DISTINCT n.facility_type),
           COALESCE(array_agg(DISTINCT n.facility_type ORDER BY n.facility_type),ARRAY[]::text[])
    FROM d_project.nearby_facilities(lon,lat,radius_m) AS n;
$$;
