-- Q1: nearest facility across all eight types.
-- Edit the longitude and latitude below to query a different location.
SELECT facility_id,facility_name,facility_type,district,address,
       round(distance_m::numeric,3) AS distance_m
FROM d_project.nearest_facility(114.1795,22.3048);

-- Q2: number of distinct assignment-level types within 500 m.
-- This is a straight-line proximity proxy, not a pedestrian route calculation.
SELECT 500 AS radius_m,facility_count,type_count,facility_types
FROM d_project.nearby_summary(114.1795,22.3048,500);

-- Supporting detail: explain which facilities produce the Q2 answer.
SELECT facility_id,facility_name,facility_type,district,
       round(distance_m::numeric,3) AS distance_m
FROM d_project.nearby_facilities(114.1795,22.3048,500);

-- Supporting breakdown: multiple facilities of the same type count once in Q2.
SELECT facility_type,count(*) AS facility_count,
       round(min(distance_m)::numeric,3) AS nearest_distance_m
FROM d_project.nearby_facilities(114.1795,22.3048,500)
GROUP BY facility_type ORDER BY facility_type;
