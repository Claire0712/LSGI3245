-- Run in a PostgreSQL database with PostGIS available.
-- The dedicated schema keeps the demonstration snapshot separate from team tables.
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE SCHEMA IF NOT EXISTS d_project;

CREATE TABLE IF NOT EXISTS d_project.facilities (
    facility_id text PRIMARY KEY,
    facility_name text NOT NULL CHECK (btrim(facility_name) <> ''),
    facility_type text NOT NULL CHECK (facility_type IN (
        'Badminton Courts','Basketball Courts','Tennis Courts','Country Parks',
        'Fitness Rooms','Parks, Zoos and Gardens','Sports Grounds','Swimming Pools')),
    district text NOT NULL,
    district_method text NOT NULL,
    address text,
    source_dataset text NOT NULL,
    source_record text NOT NULL,
    geom geometry(Point,4326) NOT NULL,
    CHECK (NOT ST_IsEmpty(geom) AND ST_IsValid(geom)),
    CHECK (ST_X(geom) BETWEEN 113.8 AND 114.5 AND ST_Y(geom) BETWEEN 22.13 AND 22.57),
    UNIQUE (source_dataset, source_record)
);

-- The indexed expression matches ST_DWithin's geography expression exactly.
CREATE INDEX IF NOT EXISTS facilities_geography_gix
    ON d_project.facilities USING gist ((geom::geography));
CREATE INDEX IF NOT EXISTS facilities_type_idx ON d_project.facilities (facility_type);

-- All query functions use this interface, which can later point to the team table.
CREATE OR REPLACE VIEW d_project.facilities_input AS
SELECT facility_id, facility_name, facility_type, district, address, geom
FROM d_project.facilities;

CREATE TABLE IF NOT EXISTS d_project.query_locations (
    location_id text PRIMARY KEY,
    label text NOT NULL,
    longitude double precision NOT NULL,
    latitude double precision NOT NULL
);
INSERT INTO d_project.query_locations VALUES
    ('Q01','Hung Hom study point',114.1795,22.3048),
    ('Q02','Central study point',114.1594,22.2819),
    ('Q03','Sha Tin study point',114.1889,22.3810),
    ('Q04','Tung Chung study point',113.9411,22.2890)
ON CONFLICT (location_id) DO UPDATE SET label=EXCLUDED.label,
    longitude=EXCLUDED.longitude, latitude=EXCLUDED.latitude;
