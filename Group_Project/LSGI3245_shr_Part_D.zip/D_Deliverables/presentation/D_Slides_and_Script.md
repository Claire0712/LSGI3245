# Part D - Three-Minute Presentation

Use four slides within the group's existing template. The material below is ready for Member A to integrate. The spoken script is approximately 336 words; rehearse with the slide transitions to fit three minutes. All numbers refer to the bundled snapshot and the exact coordinates in `data/query_locations.csv`.

## Slide 1 - From park data to reliable query inputs

**Suggested time: 0:00-0:35**

Slide content:

- D's contribution: 25 Country Parks + 124 Parks, Zoos and Gardens.
- Harmonize English fields; preserve source IDs and coordinate provenance.
- Transform Hong Kong Grid coordinates into WGS84.
- Query all eight assignment categories: 775 facility records.

Speaker script:

My part covers park-data cleaning and two location-based queries. I prepared twenty-five Country Park records and one hundred and twenty-four park, zoo and garden records. I standardized the English fields, checked duplicates and converted Hong Kong Grid coordinates into WGS84. To answer the queries correctly, I searched all eight facility categories, using a reproducible snapshot of seven hundred and seventy-five records.

## Slide 2 - Two questions, one consistent distance definition

**Suggested time: 0:35-1:15**

Slide content:

- Q1: nearest recorded facility using `ST_Distance` on geography.
- Q2: `ST_DWithin` + `COUNT(DISTINCT facility_type)`.
- Primary radius: 500 m; sensitivity checks: 400 m and 800 m.
- Metres, longitude first, deterministic ties, explicit zero results.

Speaker script:

The first query ranks facilities by spheroidal distance in metres and returns the nearest record with its type and district. The second finds facilities within five hundred metres and counts distinct categories. Five facilities can therefore represent only four types. I chose five hundred metres as an explicit assumption, and also tested four hundred and eight hundred metres. A location with no nearby facility returns zero, rather than disappearing from the results.

## Slide 3 - Actual results at four study points

**Suggested time: 1:15-2:10**

Slide content:

| Study point | Nearest facility | Distance | Types within 500 m |
| --- | --- | --- | --- |
| Hung Hom | Hong Tat Path Garden | 433.0 m | 1 |
| Central | Hong Kong Park Sports Centre | 504.7 m | 0 |
| Sha Tin | Sha Tin Park | 194.8 m | 4 |
| Tung Chung | Tung Chung Swimming Pool | 257.6 m | 4 |

Use `results/radius_sensitivity.png` as the main visual; retain the detailed table in the slide or a backup slide. The two panels most useful for a map-based explanation are Central and Sha Tin in `results/location_maps.png`.

Speaker script:

At the Hung Hom point, the nearest record is Hong Tat Path Garden, about four hundred and thirty-three metres away. In Sha Tin, it is Sha Tin Park, about one hundred and ninety-five metres away. Sha Tin and Tung Chung each have four types within five hundred metres, but their activity mixes differ. Central is especially revealing: its nearest point is about five hundred and five metres away, so its five-hundred-metre count is zero. At eight hundred metres, however, Central has four types. This shows that a zero count is sensitive to our threshold and does not mean the whole area has no facilities.

## Slide 4 - What the results establish

**Suggested time: 2:10-3:00**

Slide content:

- Reproducible SQL, source hashes, cleaning audit and independent numerical checks.
- Radius results depend on the threshold and the recorded point location.
- Straight-line proximity is a proxy; entrances and walking routes are not measured.
- Next step: verified entrances plus a pedestrian network.

Speaker script:

I checked the calculations using independent geodesic results and database tests covering ties, zero matches and boundary cases. There are also important limits. These distances refer to recorded points, not verified entrances. Country Parks can be very large, and their reference points may poorly represent access. Roads, slopes and water barriers are not modelled. Two park points also fall outside the supplied district polygons, so I preserved their official district labels and documented the mismatch. The results support a transparent comparison of nearby opportunities, while a pedestrian network and verified entrances would be needed to estimate actual walking access.

## Demonstration commands

```sql
-- Central: nearest point is just outside the primary threshold.
SELECT * FROM d_project.nearest_facility(114.1594,22.2819);
SELECT * FROM d_project.nearby_summary(114.1594,22.2819,500);
SELECT * FROM d_project.nearby_summary(114.1594,22.2819,800);
```

Expected demonstration: nearest = Hong Kong Park Sports Centre (Fitness Rooms), 504.675 m; 500 m = 0 records and 0 types; 800 m = 10 records and 4 types. Use the saved CSVs as the presentation backup if the classroom database is unavailable.

## Likely questions and concise answers

**Why did you choose 500 m?**  
It is a transparent study assumption. A direct 500 m path at an assumed 1.2 m/s takes about 6.9 minutes. I tested 400 and 800 m to show how the conclusion changes. I do not claim a universal walking standard.

**Is this real walking distance?**  
No. It is spheroidal straight-line distance to the recorded reference point. Real walking requires an accessible route and a verified entrance, which these input datasets do not provide.

**Why search all eight categories when D cleans only two?**  
The two required questions refer to facilities generally. Searching only parks could miss a nearer sports facility and would undercount the available categories.

**Why use geography?**  
Our stored geometry uses WGS84 longitude and latitude. Casting to geography gives distance in metres on the spheroid. Treating EPSG:4326 geometry distances as metres would be incorrect.

**What is the difference between facility count and type count?**  
Several records can belong to the same category. Facility count counts the records; distinct-type count measures category variety. A multi-activity venue may also occur in more than one category.

**Why can Central have zero types when there are parks nearby?**  
The exact study coordinate and reference-point distances determine inclusion. Its nearest mapped record is 504.675 m away, just outside 500 m. At 800 m the result is four types. The result is not a claim about the whole district.

**How did you clean Country Park coordinates?**  
The CSV supplied Hong Kong Grid eastings and northings. I transformed EPSG:2326 into EPSG:4326. Simply relabelling the grid values with SRID 4326 would produce invalid locations.

**What did you do with duplicates and shared venues?**  
I remove only same-type, same-name records with identical coordinates. Different categories at a shared venue remain separate opportunities. No exact duplicates were removed from this snapshot.

**What happens at the radius boundary or when there is a tie?**  
The radius includes the boundary. Exact nearest-distance ties are resolved by the unique facility ID so results are reproducible. The SQL regression tests exercise both behaviours.

**Why did two park points not match a district polygon?**  
The supplied boundary representation did not cover those reference points. I retained their provider district names and logged the discrepancy. I did not assume a cause or move the points. The group should reconcile the boundaries before district-level aggregation.

**Can you conclude that these facilities improve health or that one district is underserved?**  
Not from these queries alone. They describe proximity and category variety at four study points. Health effects, demand and district-wide equity require additional population, behavioural and access evidence.

**What would you improve next?**  
Use entrance locations and a pedestrian network, account for opening hours and capacity, and sample residential origins or population-weighted locations rather than relying on four illustrative points.
