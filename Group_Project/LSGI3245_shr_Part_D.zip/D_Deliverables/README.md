# Part D - Submission and Reproduction Guide

LSGI3245 Geospatial Database Management and Design | 2026/27 Semester 1

This package covers Member D's allocation: cleaning Country Parks and Parks, Zoos and Gardens; finding the nearest facility; and counting facility types within an assumed walking-distance threshold. All authored content and analytical tables are in English.

## 1. What to submit and share

| File or folder | Purpose |
| --- | --- |
| `report/D_Report.pdf` | Finished report contribution: methods, actual results, interpretation and limitations. |
| `report/D_Report.md` | Editable English report text for the group report. |
| `sql/` | Database setup, load, required queries, sensitivity checks, tests and optional team adapter. |
| `data/facilities_D.csv` | D's cleaned contribution: 25 Country Parks and 124 Parks, Zoos and Gardens records. Give this to Member B. |
| `data/facilities_all.csv` | A 775-record, eight-type official snapshot used to reproduce D's results. |
| `results/` | Query CSVs, cleaning audit, verification evidence and two high-resolution figures for Member E. |
| `presentation/D_Slides_and_Script.md` | Four slide-ready outlines, a timed three-minute script, and anticipated Q&A for Member A. |
| `data/source_manifest.json` | Version-specific source URLs, original archive hashes and English-input hashes. |
| `scripts/` | Reproducible cleaning, reference calculation, figure generation and report production. |

The full snapshot is supplied to test D's two queries across all eight required categories. It does not change the agreed division of labour. Do not append the six non-D categories to a team table that already contains them.

## 2. Results to reproduce

The query coordinates are deliberately specified study points, not verified entrances or exact landmark locations. Every count refers to a source facility record for a particular activity type, not to an individual court or pool basin.

| Study point | Nearest recorded facility | Type | Distance (m) | Records within 500 m | Types within 500 m |
| --- | --- | --- | --- | --- | --- |
| Hung Hom | Hong Tat Path Garden | Basketball Courts | 432.969 | 1 | 1 |
| Central | Hong Kong Park Sports Centre | Fitness Rooms | 504.675 | 0 | 0 |
| Sha Tin | Sha Tin Park | Parks, Zoos and Gardens | 194.799 | 5 | 4 |
| Tung Chung | Tung Chung Swimming Pool | Swimming Pools | 257.595 | 5 | 4 |

Distances are spheroidal WGS84 distances to the source reference points. The three decimal places support numerical verification; they do not imply millimetre source accuracy. Use one decimal place in slides.

## 3. Execute the SQL in PostgreSQL/PostGIS

### Step 1 - Prepare a dedicated database

Use PostgreSQL with PostGIS installed. The tested versions are recorded in `results/database_validation.txt`. Create an empty project database, for example `lsgi3245_d`, using pgAdmin. Connect with a role that can create the PostGIS extension, or ask the database administrator to enable it beforehand.

The scripts create only the dedicated `d_project` schema and the PostGIS extension. They do not replace the team's `public.Facilities`, `HK_Admin` or `census` tables. Population data is not needed for D's two location queries.

### Step 2 - Run the scripts in order

In pgAdmin's Query Tool, open and execute:

1. `sql/00_setup.sql` - enable PostGIS; create the demonstration facility table, query interface, indexes and four input locations.
2. `sql/01_load_snapshot.sql` - load the bundled snapshot using generated SQL literals. No file-path changes or server-side CSV permissions are required.
3. `sql/02_query_functions.sql` - create the input validator, nearest-facility function, radius function and type-count summary.
4. `sql/03_required_queries.sql` - run the two required queries at the Hung Hom example point, plus explanatory detail.
5. `sql/04_batch_and_sensitivity.sql` - run all four locations, three distance thresholds and an execution-plan check.
6. `sql/05_regression_tests.sql` - run synthetic edge cases in a transaction and roll back every fixture change.
7. `sql/06_reference_comparison.sql` - compare the database results with the independently calculated Python reference.

Execute each file completely. If a regression test fails in pgAdmin, run `ROLLBACK;` before investigating. A successful test prints PASS notices. `07_team_integration.sql` is optional and is not part of the default run.

Alternatively, from the package directory use psql:

```powershell
psql -h localhost -p 5432 -U postgres -d lsgi3245_d -v ON_ERROR_STOP=1 -f sql/run_all.psql
```

Supply credentials through the normal PostgreSQL prompt or password-file mechanism. No password is embedded in these files. Re-running the same snapshot updates matching IDs without duplication. For a different source snapshot, use a fresh demonstration database so that removed source records cannot survive as stale rows.

### Step 3 - Change the input location

The order is **longitude, latitude**, in decimal degrees:

```sql
SELECT * FROM d_project.nearest_facility(114.1795, 22.3048);
SELECT * FROM d_project.nearby_summary(114.1795, 22.3048, 500);
SELECT * FROM d_project.nearby_facilities(114.1795, 22.3048, 500);
```

The nearest query searches every facility type. The summary returns `facility_count`, `type_count` and an array of type names. A location with no matches returns one summary row containing zero counts and an empty array. A completely empty input table has no nearest-facility result.

### Step 4 - Export results

In pgAdmin, export the result grids for the batch queries as CSV. Compare them with `results/q1_nearest_reference.csv`, `q2_summary_reference.csv` and `radius_sensitivity_reference.csv`. `q2_detail_reference.csv` identifies every facility behind the 500 m counts. The independently generated reference uses the same cleaned coordinates but a separate geodesic implementation.

## 4. Reproduce the data-cleaning workflow

The bundled `data/source_english/` files preserve the source's required English analytical columns. Original bilingual archives were downloaded from the official version-specific URLs in `source_manifest.json`; SHA-256 values identify the exact archives and original CSV members. The immutable English inputs allow reproduction without another download.

1. Verify the English input SHA-256 hashes; the cleaning script does this automatically and stops if a file changed.
2. Read each CSV as UTF-8. Normalize display text by trimming whitespace, decoding HTML entities and removing HTML markup.
3. Map `NAME_EN` or `NameEN` to `facility_name`; map `ADDRESS_EN` or `AddressEN` to `address`. Fix `facility_type` to the assignment-level dataset category. Do not split a park's amenities into extra categories.
4. Prefer source geometry coordinates. Use `GeometryLongitude` and `GeometryLatitude` where provided. Otherwise transform `GeometryEasting` and `GeometryNorthing` from Hong Kong 1980 Grid, EPSG:2326, into WGS84, EPSG:4326. Use coordinate attributes only as a fallback. A CRS transformation changes coordinates; simply assigning SRID 4326 to Hong Kong grid numbers is incorrect.
5. Require a non-empty English name and finite coordinates within a broad Hong Kong screening envelope: longitude 113.8-114.5, latitude 22.13-22.57. Quarantine invalid records; do not guess locations.
6. Remove only records with the same normalized name, type and identical coordinates. Preserve different activity types at the same venue. Flag same-name, same-type records more than 1 km apart for review instead of silently merging them.
7. Keep provider district names if they match the supplied 18-district vocabulary. Otherwise use a unique point-in-polygon match against the supplied district boundaries. Preserve both provider and spatial district fields. Do not invent a district for an unmatched point.
8. Compare geometry coordinates against latitude/longitude attributes. Differences over 5 m are recorded as review flags; source geometry remains the stated canonical representation.
9. Write `facilities_D.csv`, `facilities_all.csv`, cleaning counts and record-level quality issues. For Country Parks, the district tag describes the representative point, not the entire park footprint.
10. Compute independent geodesic answers, check invariants and generate the SQL load file. Source-row numbering is a snapshot-local identifier where the provider supplies no OBJECTID; it is not a guaranteed cross-version identifier.

Run the pipeline with Python 3.11 or later:

```powershell
python -m pip install -r requirements.txt
python scripts/clean_and_analyse.py
python scripts/build_reference_tests.py
python scripts/make_figures.py
python scripts/build_report.py
```

Only the cleaning/reference calculation needs `pyproj` and `shapely`. The remaining packages generate the figures and report. The source manifest, query-point CSV and resulting SQL must travel together when reproducing the findings.

## 5. Connect to the team's final Facilities table

Give Member B the D-only CSV and the data dictionary. Agree on a shared eight-value type vocabulary. Do not add `Park`, `Garden` and `Zoo` as three separate assignment-level types: they belong to the combined `Parks, Zoos and Gardens` category.

The query functions read `d_project.facilities_input`. `sql/07_team_integration.sql` contains a commented adapter example. Map the actual team columns to the required interface: unique text `facility_id`, `facility_name`, `facility_type`, `district`, `address`, and `geometry(Point,4326)` named `geom`. Use `ST_Transform` only when the existing geometry has its correct source SRID. Never use it to repair a wrongly labelled CRS.

After connecting the team table, verify eight types, unique IDs, non-null names and valid point geometry. Re-run the batch queries and export fresh figures if the team's snapshot differs. The fixed reference comparison is intended for the bundled snapshot; differences after a legitimate data change must be explained, not concealed.

## 6. Interpretation boundaries

- The 500 m threshold is an explicit study assumption. At an assumed speed of 1.2 m/s, a direct 500 m path would take about 6.9 minutes. Neither that speed nor the threshold is claimed to be a universal planning standard.
- Straight-line proximity is a screening proxy. Actual walking depends on crossings, footbridges, slopes, water, entrances and opening restrictions. There is no pedestrian network or routing analysis in this package.
- Country Park points are not verified entrances or boundaries. A visitor may be near a park entrance while far from its reference point, or the reverse.
- Counts measure recorded opportunities, not capacity, quality, admission cost, current availability or individual health outcomes. Four chosen study points cannot establish territory-wide equity or causation.
- Two D park points have no match in the supplied polygon layer. Their official provider districts are retained and the discrepancy is documented. Reconcile boundary vintage before using those districts for Member E's district-level rankings.
- Source-geometry and coordinate-attribute differences occur in the supporting six-category snapshot. Geometry is the consistent reference representation; the audit enables the team to inspect any records near a threshold.

## 7. Sources and attribution

Facility data: Government of the Hong Kong SAR, AFCD and LCSD, via the [Common Spatial Data Infrastructure (CSDI) Portal](https://portal.csdi.gov.hk/csdi-webpage/doc/TNC), under its terms and conditions. Detailed dataset links and hashes appear in `data/source_manifest.json`. District geometry: instructor-provided HKDistrict18 shapefile; CRS verified from the supplied `.prj` file. The provided census workbook is not used in Part D.

Method documentation: [ST_Distance](https://postgis.net/docs/ST_Distance.html), [ST_DWithin](https://postgis.net/docs/ST_DWithin.html), [ST_Transform](https://postgis.net/docs/ST_Transform.html), and [ST_Covers](https://postgis.net/docs/ST_Covers.html).
