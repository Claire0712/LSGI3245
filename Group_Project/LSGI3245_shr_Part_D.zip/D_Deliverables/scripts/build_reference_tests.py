"""Generate SQL assertions from the independent Python reference outputs."""
from pathlib import Path
import csv
ROOT=Path(__file__).resolve().parents[1]
def rows(name):
    return list(csv.DictReader((ROOT/'results'/name).open(encoding='utf-8')))
def quote(value):
    return "'"+str(value).replace("'","''")+"'"
nearest=rows('q1_nearest_reference.csv')
sensitivity=rows('radius_sensitivity_reference.csv')
parts=["-- Compare PostGIS outputs against independently computed WGS84/PROJ results.",
       "-- Run against the bundled snapshot; a different team snapshot may legitimately differ.",
       "BEGIN;", "CREATE TEMP TABLE expected_nearest (location_id text,facility_id text,distance_m double precision) ON COMMIT DROP;",
       "INSERT INTO expected_nearest VALUES\n"+",\n".join("("+quote(r['location_id'])+","+quote(r['facility_id'])+","+r['distance_m']+")" for r in nearest)+";",
       "CREATE TEMP TABLE expected_radius (location_id text,radius_m integer,facility_count bigint,type_count bigint) ON COMMIT DROP;",
       "INSERT INTO expected_radius VALUES\n"+",\n".join("("+quote(r['location_id'])+","+r['radius_m']+","+r['facility_count']+","+r['type_count']+")" for r in sensitivity)+";",
       """DO $$
BEGIN
 IF (SELECT count(*) FROM d_project.facilities_input) <> 775 OR
    (SELECT count(DISTINCT facility_type) FROM d_project.facilities_input) <> 8 THEN
   RAISE EXCEPTION 'FAIL: reference tests require the bundled 775-row, eight-type snapshot';
 END IF;
 IF EXISTS (
   SELECT 1 FROM expected_nearest e
   JOIN d_project.query_locations q USING(location_id)
   LEFT JOIN LATERAL d_project.nearest_facility(q.longitude,q.latitude) n ON true
   WHERE n.facility_id IS DISTINCT FROM e.facility_id OR abs(n.distance_m-e.distance_m)>0.002
 ) THEN RAISE EXCEPTION 'FAIL: nearest result differs from independent reference'; END IF;
 IF EXISTS (
   SELECT 1 FROM expected_radius e
   JOIN d_project.query_locations q USING(location_id)
   CROSS JOIN LATERAL d_project.nearby_summary(q.longitude,q.latitude,e.radius_m) s
   WHERE s.facility_count<>e.facility_count OR s.type_count<>e.type_count
 ) THEN RAISE EXCEPTION 'FAIL: radius counts differ from independent reference'; END IF;
 RAISE NOTICE 'PASS: four nearest results and twelve radius scenarios match the independent reference';
END;
$$;
COMMIT;
"""]
(ROOT/'sql/06_reference_comparison.sql').write_text('\n'.join(parts),encoding='utf-8')
