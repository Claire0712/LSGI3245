"""Create exportable figures from the bundled analytical snapshot."""
from pathlib import Path
import csv,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle
from pyproj import Transformer
ROOT=Path(__file__).resolve().parents[1]
def read(name):
    return list(csv.DictReader((ROOT/name).open(encoding='utf-8')))
rows=read('data/facilities_all.csv')
queries=read('data/query_locations.csv')
counts=read('results/q2_summary_reference.csv')
near=read('results/q1_nearest_reference.csv')
sensitivity=read('results/radius_sensitivity_reference.csv')
types=['Badminton Courts','Basketball Courts','Tennis Courts','Country Parks','Fitness Rooms','Parks, Zoos and Gardens','Sports Grounds','Swimming Pools']
palette=['#3568ae','#dd7840','#bf4949','#26724c','#936bb4','#40a4a0','#7b6b58','#2483bb']
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'savefig.facecolor':'white'})
fig,ax=plt.subplots(figsize=(10,4.3),layout='constrained')
x=np.arange(4)
for k,(radius,color) in enumerate(zip([400,500,800],['#b3c4d8','#29618b','#e9ac55'])):
    values=[int(next(s['type_count'] for s in sensitivity if s['location_id']==q['location_id'] and int(s['radius_m'])==radius)) for q in queries]
    bars=ax.bar(x+(k-1)*.23,values,width=.22,color=color,label=f'{radius} m')
    ax.bar_label(bars,padding=3)
ax.set_xticks(x,[q['label'].replace(' study point','') for q in queries]);ax.set_ylim(0,8)
ax.set_ylabel('Distinct assignment-level facility types')
ax.set_title('Facility choice depends on the distance threshold',loc='left',fontweight='bold',pad=15)
ax.legend(frameon=False,ncol=3,loc='upper left');ax.grid(axis='y',alpha=.15);ax.set_axisbelow(True)
fig.savefig(ROOT/'results/radius_sensitivity.png',dpi=220);plt.close(fig)

project=Transformer.from_crs(4326,2326,always_xy=True)
districts=json.loads((ROOT/'data/districts.geojson').read_text())
fig,axes=plt.subplots(2,2,figsize=(10,9))
for ax,q,s,n in zip(axes.flat,queries,counts,near):
    qx,qy=project.transform(float(q['longitude']),float(q['latitude']))
    for feature in districts['features']:
        g=feature['geometry']; polygons=g['coordinates'] if g['type']=='MultiPolygon' else [g['coordinates']]
        for polygon in polygons:
            for ring in polygon:
                xx,yy=project.transform(*zip(*ring))
                ax.plot(np.array(xx)-qx,np.array(yy)-qy,color='#d7dce2',linewidth=.7,zorder=0)
    for radius,style in [(800,':'),(500,'--')]:
        ax.add_patch(Circle((0,0),radius,fill=False,edgecolor='#657381',linestyle=style,linewidth=1))
    for kind,color in zip(types,palette):
        points=[project.transform(float(r['longitude']),float(r['latitude'])) for r in rows if r['facility_type']==kind]
        ax.scatter([p[0]-qx for p in points],[p[1]-qy for p in points],s=32,color=color,label=kind,zorder=3,edgecolor='white',linewidth=.4)
    nr=next(r for r in rows if r['facility_id']==n['facility_id']);nx,ny=project.transform(float(nr['longitude']),float(nr['latitude']))
    ax.plot([0,nx-qx],[0,ny-qy],color='#26374a',linewidth=1,zorder=2)
    ax.scatter([0],[0],marker='*',s=150,color='#142c43',edgecolor='white',zorder=5)
    ax.text(.03,.03,f"Nearest: {float(n['distance_m']):.1f} m\n500 m: {s['facility_count']} records / {s['type_count']} types",transform=ax.transAxes,fontsize=9,bbox=dict(facecolor='white',alpha=.9,edgecolor='none'))
    ax.set_title(q['location_id']+' | '+q['label'].replace(' study point',''),loc='left',fontweight='bold')
    ax.set_xlim(-1050,1050);ax.set_ylim(-1050,1050);ax.set_aspect('equal')
    ax.set_xlabel('East of query point (m)');ax.set_ylabel('North of query point (m)')
    ax.grid(alpha=.12)
handles,labels=axes[0,0].get_legend_handles_labels()
fig.legend(handles,labels,loc='lower center',ncol=3,frameon=False,fontsize=9,bbox_to_anchor=(.5,.025))
fig.suptitle('Local facility patterns around four reproducible study points',fontweight='bold',y=.99)
fig.text(.5,.006,'Points: CSDI Portal (AFCD / LCSD). Boundaries: supplied HKDistrict18. Display: EPSG:2326. Distances: WGS84 geodesic.',ha='center',fontsize=7)
fig.subplots_adjust(left=.08,right=.98,bottom=.16,top=.94,wspace=.28,hspace=.3)
fig.savefig(ROOT/'results/location_maps.png',dpi=220);plt.close(fig)
print('Created two publication-ready figures')
