"""Render the editable English report to a paginated PDF."""
from pathlib import Path
from html import escape
import re
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, Preformatted, KeepTogether

ROOT=Path(__file__).resolve().parents[1]
REPORT=ROOT/'report'
WIDTH=A4[0]-88
styles=getSampleStyleSheet()
styles.add(ParagraphStyle(name='ReportTitle',fontName='Helvetica-Bold',fontSize=23,leading=28,textColor=colors.HexColor('#17364b'),spaceAfter=16))
styles.add(ParagraphStyle(name='Section',fontName='Helvetica-Bold',fontSize=13.5,leading=18,textColor=colors.HexColor('#17364b'),spaceBefore=16,spaceAfter=8,keepWithNext=True))
styles.add(ParagraphStyle(name='Subsection',fontName='Helvetica-Bold',fontSize=10.5,leading=14,spaceBefore=11,spaceAfter=6,keepWithNext=True))
styles.add(ParagraphStyle(name='ReportBody',fontName='Helvetica',fontSize=9.5,leading=14,spaceAfter=7,splitLongWords=True))
styles.add(ParagraphStyle(name='TableBody',fontName='Helvetica',fontSize=8,leading=11,spaceAfter=0,splitLongWords=True))
styles.add(ParagraphStyle(name='TableHeader',parent=styles['TableBody'],fontName='Helvetica-Bold',textColor=colors.white))
styles.add(ParagraphStyle(name='Caption',fontName='Helvetica-Oblique',fontSize=8,leading=11,textColor=colors.HexColor('#526474'),spaceAfter=10))
styles.add(ParagraphStyle(name='CodeBlock',fontName='Courier',fontSize=7.7,leading=11,backColor=colors.HexColor('#f0f4f7'),borderPadding=9,spaceBefore=5,spaceAfter=10))

def inline(s):
    s=escape(s)
    s=re.sub(r'\*\*(.*?)\*\*',r'<b>\1</b>',s)
    s=re.sub(r'`([^`]+)`',r'<font name="Courier">\1</font>',s)
    return s

def table(lines):
    cells=[[c.strip() for c in line.strip().strip('|').split('|')] for line in lines]
    cells=[row for row in cells if not all(re.fullmatch(r'[-: ]+',c) for c in row)]
    n=len(cells[0])
    if n==5: weights=[.18,.14,.14,.36,.18]
    elif n==4 and 'Included types' in cells[0]: weights=[.17,.14,.15,.54]
    elif n==4 and 'Responsibility' in cells[0]: weights=[.4,.15,.15,.3]
    else: weights=[1/n]*n
    formatted=[[Paragraph(inline(c),styles['TableHeader' if i==0 else 'TableBody']) for c in row] for i,row in enumerate(cells)]
    t=Table(formatted,colWidths=[WIDTH*w for w in weights],repeatRows=1,hAlign='LEFT')
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#24576b')),
                          ('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.HexColor('#f1f5f7'),colors.white]),
                          ('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),6),
                          ('RIGHTPADDING',(0,0),(-1,-1),6),('TOPPADDING',(0,0),(-1,-1),7),
                          ('BOTTOMPADDING',(0,0),(-1,-1),7),
                          ('LINEBELOW',(0,0),(-1,0),.5,colors.HexColor('#24576b'))]))
    return t

def footer(canvas,doc):
    canvas.saveState()
    canvas.setStrokeColor(colors.HexColor('#c7d4df'));canvas.line(44,40,A4[0]-44,40)
    canvas.setFont('Helvetica',8);canvas.setFillColor(colors.HexColor('#526474'))
    canvas.drawString(44,27,'LSGI3245 | Part D | Location-based facility queries')
    canvas.drawRightString(A4[0]-44,27,str(doc.page))
    canvas.restoreState()

lines=(REPORT/'D_Report.md').read_text(encoding='utf-8').splitlines()
story=[];i=0
while i<len(lines):
    line=lines[i].strip()
    if not line: i+=1;continue
    if line.startswith('```'):
        code=[];i+=1
        while i<len(lines) and not lines[i].startswith('```'):
            code.append(lines[i]);i+=1
        story.append(Preformatted('\n'.join(code),styles['CodeBlock']));i+=1;continue
    if line.startswith('|'):
        block=[]
        while i<len(lines) and lines[i].strip().startswith('|'):
            block.append(lines[i]);i+=1
        story.extend([table(block),Spacer(1,9)]);continue
    if line.startswith('!['):
        m=re.match(r'!\[(.*?)\]\((.*?)\)',line)
        image=Image(str((REPORT/m[2]).resolve()))
        max_height=420 if 'location_maps' in m[2] else 230
        scale=min(WIDTH/image.imageWidth,max_height/image.imageHeight)
        image.drawWidth=image.imageWidth*scale;image.drawHeight=image.imageHeight*scale
        story.append(KeepTogether([Spacer(1,7),image,Paragraph(inline(m[1]),styles['Caption'])]));i+=1;continue
    if line.startswith('# '): style='ReportTitle';body=line[2:]
    elif line.startswith('## '): style='Section';body=line[3:]
    elif line.startswith('### '): style='Subsection';body=line[4:]
    else:
        style='ReportBody';body=line
        if body.startswith('- '):body='- '+body[2:]
        while i+1<len(lines) and lines[i+1].strip() and not lines[i+1].lstrip().startswith(('#','|','```','![','- ')):
            i+=1;body+=' '+lines[i].strip()
    story.append(Paragraph(inline(body),styles[style]));i+=1

doc=SimpleDocTemplate(str(REPORT/'D_Report.pdf'),pagesize=A4,rightMargin=44,leftMargin=44,
                      topMargin=42,bottomMargin=55,title='LSGI3245 Part D - Location-Based Facility Queries',
                      author='LSGI3245 Project',subject='Data cleaning, nearest facility and radius-based facility diversity')
doc.build(story,onFirstPage=footer,onLaterPages=footer)
print('Created report/D_Report.pdf')
