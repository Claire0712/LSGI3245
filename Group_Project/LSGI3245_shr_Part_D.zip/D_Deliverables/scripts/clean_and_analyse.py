"""Rebuild the English facility tables and independent geodesic reference results.

Run from any directory: python scripts/clean_and_analyse.py
Dependencies: pyproj, shapely. Input snapshots and district geometry are bundled.
"""
from pathlib import Path
from collections import Counter, defaultdict
import csv
import hashlib
import html
import json
import math
import re
from pyproj import Geod, Transformer
from shapely.geometry import Point, shape

ROOT = Path(__file__).resolve().parents[1]
GEOD = Geod(ellps="WGS84")
TO_WGS84 = Transformer.from_crs(2326, 4326, always_xy=True)
TYPES = ["Badminton Courts", "Basketball Courts", "Tennis Courts", "Country Parks",
         "Fitness Rooms", "Parks, Zoos and Gardens", "Sports Grounds", "Swimming Pools"]
D_TYPES = {"Country Parks", "Parks, Zoos and Gardens"}
FIELDS = ["facility_id", "facility_name", "facility_type", "district", "district_method",
          "source_district", "spatial_district", "address", "longitude", "latitude",
          "coordinate_method", "source_dataset", "source_record", "source_last_update"]


def write_csv(path, rows, fields):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def text(value):
    return re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]*>", " ", value or ""))).strip()


def pick(row, *keys):
    return next((text(row[k]) for k in keys if row.get(k) and text(row[k])), "")


def distance(lon, lat, row):
    return GEOD.inv(lon, lat, row["longitude"], row["latitude"])[2]


def clean():
    manifest = json.loads((ROOT / "data/source_manifest.json").read_text())
    districts = json.loads((ROOT / "data/districts.geojson").read_text())
    polygons = [(f["properties"]["district_name"], shape(f["geometry"]))
                for f in districts["features"]]
    valid_names = {name for name, _ in polygons}
    assert len(polygons) == 18 and all(g.is_valid for _, g in polygons)
    output, issues, summary = [], [], []
    seen = {}
    for source in manifest:
        path = ROOT / source["english_snapshot"]
        assert hashlib.sha256(path.read_bytes()).hexdigest() == source["english_sha256"], path
        rows = list(csv.DictReader(path.open(encoding="utf-8-sig")))
        accepted = duplicates = rejected = 0
        for i, row in enumerate(rows, 1):
            record = pick(row, "OBJECTID") or str(i)
            facility_id = source["short_code"] + ":" + record
            name = pick(row, "NAME_EN", "NameEN")
            try:
                if row.get("GeometryLongitude") and row.get("GeometryLatitude"):
                    lon, lat = float(row["GeometryLongitude"]), float(row["GeometryLatitude"])
                    method = "Source geometry WGS84"
                elif row.get("GeometryEasting") and row.get("GeometryNorthing"):
                    lon, lat = TO_WGS84.transform(float(row["GeometryEasting"]), float(row["GeometryNorthing"]))
                    method = "Source geometry EPSG:2326 transformed to EPSG:4326"
                else:
                    lon, lat = float(row["LONGITUDE"]), float(row["LATITUDE"])
                    method = "Source longitude and latitude WGS84"
                if not name or not all(map(math.isfinite, [lon, lat])) or not (113.8 <= lon <= 114.5 and 22.13 <= lat <= 22.57):
                    raise ValueError("Missing name or coordinates outside the Hong Kong screening envelope")
            except (KeyError, TypeError, ValueError) as exc:
                rejected += 1
                issues.append(dict(facility_id=facility_id, issue="REJECTED", detail=str(exc)))
                continue
            # Match only truly identical normalized records; retain different activity types.
            key = (source["facility_type"], name.casefold(), lon, lat)
            if key in seen:
                duplicates += 1
                issues.append(dict(facility_id=facility_id, issue="EXACT_DUPLICATE", detail="Retained " + seen[key]))
                continue
            seen[key] = facility_id
            matches = sorted(n for n, poly in polygons if poly.covers(Point(lon, lat)))
            source_district = pick(row, "DistrictEN", "SEARCH01_EN").upper()
            # Legacy LCSD SEARCH01_EN is used only if it exactly matches a district name.
            if source_district not in valid_names:
                source_district = ""
            spatial_district = "; ".join(matches)
            if source_district:
                district, district_method = source_district, "Provider district"
                if source_district not in matches:
                    issues.append(dict(facility_id=facility_id, issue="DISTRICT_REVIEW", detail="Provider=" + source_district + "; polygon=" + (spatial_district or "none")))
            elif len(matches) == 1:
                district, district_method = matches[0], "Reference point covered by district polygon"
            else:
                district, district_method = "Unassigned", "No unique polygon match"
                issues.append(dict(facility_id=facility_id, issue="DISTRICT_REVIEW", detail=spatial_district or "No polygon match; no district guessed"))
            if row.get("LONGITUDE") and row.get("LATITUDE"):
                try:
                    diff = GEOD.inv(lon, lat, float(row["LONGITUDE"]), float(row["LATITUDE"]))[2]
                    if math.isfinite(diff) and diff > 5:
                        issues.append(dict(facility_id=facility_id, issue="COORDINATE_REVIEW", detail=f"Geometry versus coordinate attribute: {diff:.3f} m; geometry retained"))
                except ValueError:
                    pass
            output.append(dict(facility_id=facility_id, facility_name=name, facility_type=source["facility_type"],
                               district=district, district_method=district_method, source_district=source_district,
                               spatial_district=spatial_district, address=pick(row, "AddressEN", "ADDRESS_EN"),
                               longitude=lon, latitude=lat, coordinate_method=method,
                               source_dataset=source["dataset_id"], source_record=record,
                               source_last_update=pick(row, "LASTUPDATE")))
            accepted += 1
        summary.append(dict(facility_type=source["facility_type"], input_rows=len(rows), accepted_rows=accepted,
                            duplicates_removed=duplicates, rejected_rows=rejected))
    output.sort(key=lambda r: r["facility_id"])
    assert len({r["facility_id"] for r in output}) == len(output)
    assert set(r["facility_type"] for r in output) == set(TYPES)
    by_name = defaultdict(list)
    for row in output:
        by_name[(row["facility_type"], row["facility_name"].casefold())].append(row)
    for group in by_name.values():
        for j, a in enumerate(group):
            for b in group[j + 1:]:
                separation = distance(a["longitude"], a["latitude"], b)
                if separation > 1000:
                    issues.append(dict(facility_id=a["facility_id"], issue="SAME_NAME_REVIEW", detail=f"Same type and name as {b['facility_id']}; separation {separation:.1f} m; retained pending source review"))
    write_csv(ROOT / "data/facilities_all.csv", output, FIELDS)
    write_csv(ROOT / "data/facilities_D.csv", [r for r in output if r["facility_type"] in D_TYPES], FIELDS)
    write_csv(ROOT / "results/cleaning_summary.csv", summary, list(summary[0]))
    write_csv(ROOT / "results/quality_issues.csv", issues, ["facility_id", "issue", "detail"])
    return output, summary, issues


def analyse(rows):
    queries = list(csv.DictReader((ROOT / "data/query_locations.csv").open()))
    nearest, counts, detail, sensitivity = [], [], [], []
    for query in queries:
        lon, lat = float(query["longitude"]), float(query["latitude"])
        ranked = sorted(((distance(lon, lat, r), r) for r in rows), key=lambda x: (x[0], x[1]["facility_id"]))
        d, r = ranked[0]
        nearest.append(dict(location_id=query["location_id"], label=query["label"], longitude=lon, latitude=lat,
                            facility_id=r["facility_id"], facility_name=r["facility_name"], facility_type=r["facility_type"],
                            district=r["district"], distance_m=round(d, 3)))
        for radius in [400, 500, 800]:
            nearby = [(d, r) for d, r in ranked if d <= radius]
            type_counts = Counter(r["facility_type"] for _, r in nearby)
            types = sorted(type_counts)
            result = dict(location_id=query["location_id"], label=query["label"], radius_m=radius,
                          facility_count=len(nearby), type_count=len(types), types="; ".join(types))
            sensitivity.append(result)
            if radius == 500:
                counts.append(result)
                for d, r in nearby:
                    detail.append(dict(location_id=query["location_id"], radius_m=radius, facility_id=r["facility_id"],
                                       facility_name=r["facility_name"], facility_type=r["facility_type"], district=r["district"],
                                       distance_m=round(d, 3)))
    for filename, records in [("q1_nearest_reference.csv", nearest), ("q2_summary_reference.csv", counts),
                              ("q2_detail_reference.csv", detail), ("radius_sensitivity_reference.csv", sensitivity)]:
        write_csv(ROOT / "results" / filename, records, list(records[0]) if records else [])
    checks = []
    def check(name, condition):
        checks.append(dict(test=name, result="PASS" if condition else "FAIL"))
        assert condition, name
    check("All eight assignment types are present", len({r["facility_type"] for r in rows}) == 8)
    check("Identifiers are unique", len({r["facility_id"] for r in rows}) == len(rows))
    check("All reference-point self-distances are zero", all(abs(distance(r["longitude"], r["latitude"], r)) < 1e-8 for r in rows))
    check("All detailed 500 m results satisfy the threshold", all(r["distance_m"] <= 500.0005 for r in detail))
    check("Facility count and distinct-type count are consistent", all(c["type_count"] <= c["facility_count"] for c in counts))
    for q in queries:
        sample = [s for s in sensitivity if s["location_id"] == q["location_id"]]
        check(q["location_id"] + " has monotonic counts as radius increases",
              all(a["facility_count"] <= b["facility_count"] and a["type_count"] <= b["type_count"] for a, b in zip(sample, sample[1:])))
    write_csv(ROOT / "results/reference_checks.csv", checks, ["test", "result"])
    return nearest, counts, sensitivity


def literal(value):
    return "'" + str(value).replace("'", "''") + "'"


def create_load_sql(rows):
    lines = ["-- Generated from the bundled, audited English snapshot.",
             "-- This script only writes to the dedicated d_project schema.", "BEGIN;"]
    for r in rows:
        vals = [literal(r[k]) for k in ["facility_id", "facility_name", "facility_type", "district", "district_method", "address", "source_dataset", "source_record"]]
        vals.append(f"ST_SetSRID(ST_MakePoint({r['longitude']:.14f}, {r['latitude']:.14f}),4326)")
        lines.append("INSERT INTO d_project.facilities (facility_id,facility_name,facility_type,district,district_method,address,source_dataset,source_record,geom) VALUES (" + ",".join(vals) + ") ON CONFLICT (facility_id) DO UPDATE SET facility_name=EXCLUDED.facility_name,facility_type=EXCLUDED.facility_type,district=EXCLUDED.district,district_method=EXCLUDED.district_method,address=EXCLUDED.address,source_dataset=EXCLUDED.source_dataset,source_record=EXCLUDED.source_record,geom=EXCLUDED.geom;")
    lines += ["COMMIT;", "ANALYZE d_project.facilities;", "SELECT facility_type, count(*) AS facility_count FROM d_project.facilities GROUP BY facility_type ORDER BY facility_type;"]
    (ROOT / "sql/01_load_snapshot.sql").write_text("\n".join(lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    rows, summary, issues = clean()
    nearest, counts, sensitivity = analyse(rows)
    create_load_sql(rows)
    print(json.dumps({"facilities": len(rows), "D_facilities": sum(r["facility_type"] in D_TYPES for r in rows),
                      "quality_issues": len(issues), "nearest": nearest, "within_500_m": counts}, indent=2))
