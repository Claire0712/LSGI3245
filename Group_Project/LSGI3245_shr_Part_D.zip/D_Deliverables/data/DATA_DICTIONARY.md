# Cleaned Facility Data Dictionary

One row represents one source facility record in one assignment-level facility category. Different activities at the same venue remain separate records. The CRS is EPSG:4326 and coordinate order is longitude, latitude.

| Field | Type | Definition and rule |
| --- | --- | --- |
| facility_id | text | Unique snapshot ID: dataset short code plus source OBJECTID or original row number. |
| facility_name | text | Non-empty English source name after whitespace and HTML normalization. |
| facility_type | text | One of the eight exact dataset categories used in the assignment. |
| district | text | Provider district when available and recognized; otherwise a unique spatial match. |
| district_method | text | Records whether the district came from the provider or the point-in-polygon assignment. |
| source_district | text | Recognized provider district, if supplied. Empty means unavailable. |
| spatial_district | text | District polygon covering the reference point; multiple matches would be separated by semicolons. |
| address | text | English address where supplied. Empty does not invalidate a facility. |
| longitude | double precision | WGS84 longitude in decimal degrees; X coordinate. |
| latitude | double precision | WGS84 latitude in decimal degrees; Y coordinate. |
| coordinate_method | text | Documents source geometry, CRS transformation or attribute fallback. |
| source_dataset | text | Official CSDI dataset identifier. |
| source_record | text | Provider OBJECTID when present; otherwise the original one-based CSV row number. |
| source_last_update | text | Unmodified source LASTUPDATE value where available; empty is not replaced with a retrieval date. |

The SQL demonstration table retains the core analytical fields plus `geom geometry(Point,4326)`. The richer CSV preserves the audit trail. No census geometry or population field is introduced because these two queries do not require census data.

The canonical categories are: Badminton Courts; Basketball Courts; Tennis Courts; Country Parks; Fitness Rooms; Parks, Zoos and Gardens; Sports Grounds; Swimming Pools.

District names use the supplied uppercase English vocabulary, including `CENTRAL & WESTERN`. Country Parks can span several districts; the single point-derived tag does not describe their complete spatial extent.
