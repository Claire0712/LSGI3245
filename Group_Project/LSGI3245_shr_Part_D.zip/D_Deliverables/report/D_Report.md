# Location-Based Queries for Sports and Outdoor Facilities in Hong Kong

**LSGI3245 Final Project - Member D Contribution**  
**Data snapshot retrieved: 3 November 2026**

## 1. Purpose and scope

This contribution addresses two questions: (1) which recorded sports or outdoor facility is nearest to a specified geographic location, and (2) how many distinct facility types occur within a reasonable proximity threshold? It also documents the cleaning of Country Parks and Parks, Zoos and Gardens, the two datasets allocated to Member D.

The analysis uses a reproducible snapshot of all eight facility categories required by the assignment. Restricting the two queries to D's park records would omit other nearby opportunities and could return an incorrect nearest facility for the group study. The other six categories are therefore included as supporting query inputs, while the D-only handover remains separately identifiable.

At the four specified study points, the nearest recorded facilities are 194.8-504.7 m away. Within 500 m, the number of distinct types is 1 in Hung Hom, 0 in Central, 4 in Sha Tin and 4 in Tung Chung. These are local proximity results for the stated coordinates, not district-wide accessibility estimates or evidence of effects on health.

## 2. Data sources and analytical unit

Official facility CSV archives were obtained from the Government of the Hong Kong SAR through the Common Spatial Data Infrastructure (CSDI) Portal. AFCD supplies Country Parks; LCSD supplies the other seven categories. Version-specific URLs, original archive and CSV hashes, English input hashes, and retrieval dates are recorded in `data/source_manifest.json`.

| Facility category | Source records | Cleaned records | Responsibility |
| --- | --- | --- | --- |
| Country Parks | 25 | 25 | D |
| Parks, Zoos and Gardens | 124 | 124 | D |
| Badminton Courts | 116 | 116 | Supporting input |
| Basketball Courts | 306 | 306 | Supporting input |
| Tennis Courts | 53 | 53 | Supporting input |
| Fitness Rooms | 80 | 80 | Supporting input |
| Sports Grounds | 25 | 25 | Supporting input |
| Swimming Pools | 46 | 46 | Supporting input |
| Total | 775 | 775 | Eight categories |

One observation represents a source facility record within an assignment-level category. It does not necessarily represent one individual court. A venue offering badminton and fitness remains two activity records. Conversely, the amenities listed inside a park record do not create additional assignment-level categories. Parks, Zoos and Gardens is consistently counted as one category.

The instructor-provided HKDistrict18 shapefile contains 18 districts. Its accompanying projection file identifies WGS84 geographic coordinates. The census workbook is not required for these two location queries; population-based comparisons belong elsewhere in the group project.

## 3. Cleaning and quality control

### 3.1 Reproducible field harmonization

The pipeline reads UTF-8 CSVs, selects the relevant English columns, removes HTML markup from display fields, decodes HTML entities and normalizes whitespace. `NAME_EN` and `NameEN` become `facility_name`; the equivalent address fields become `address`. `facility_type` is assigned from the dataset category rather than from a free-text amenities field. The cleaned CSV retains source identifiers, original update values, coordinate provenance and the district-assignment method.

Each record receives a unique snapshot identifier comprising a dataset prefix and its OBJECTID, or its original one-based CSV row number if OBJECTID is absent. Row-based identifiers are not assumed to remain stable across later source releases. Separate outputs contain D's 149 records and the complete 775-record query snapshot.

### 3.2 Coordinates and geometry

Source geometry is the canonical position. Converted CSVs containing `GeometryLongitude` and `GeometryLatitude` are read as geographic coordinates. Where `GeometryEasting` and `GeometryNorthing` are supplied, the pipeline transforms Hong Kong 1980 Grid coordinates, EPSG:2326, into WGS84, EPSG:4326. This transformation is essential for Country Parks, whose supplied CSV has no longitude or latitude attributes.

The database geometry is constructed as `ST_SetSRID(ST_MakePoint(longitude, latitude), 4326)`. Setting an SRID labels a coordinate system; it does not transform Hong Kong grid numbers into longitude and latitude. Geometry is subsequently cast to `geography` for metre-based geodesic distance calculations.

### 3.3 Validation and audit decisions

Records require a non-empty English name and finite coordinates within a broad Hong Kong screening envelope. Duplicate detection uses category, normalized name and identical coordinates. Different categories at the same location are retained. No records in this snapshot were rejected or removed as exact duplicates; all 149 D records passed the name and coordinate checks.

Provider district names are preserved when they match the 18-district English vocabulary. Where a provider district is absent, a unique district polygon covering the reference point supplies the district. Both provider and spatial labels remain available for auditing. A Country Park's point-based district is not a description of the park's entire footprint, which may cross several districts.

Two D records have no covering polygon in the supplied boundary layer: Tsing Bik Sitting-out Area and East Coast Park (Phase 1). Their provider districts, TUEN MUN and WAN CHAI respectively, are retained. Three supporting records around Victoria Park also have provider/polygon district disagreements. These issues may reflect differences in boundary vintage or representation; no boundary correction is invented. They do not change the coordinate-based nearest or radius queries, but should be reconciled before district-level aggregation.

Across the full supporting snapshot, 186 records have source-geometry positions more than 5 m from their latitude/longitude attributes; the largest difference is about 54.3 m. Geometry remains the explicitly chosen canonical representation, and all discrepancies are logged. D's two categories have no such differences exceeding 5 m. This audit matters because small coordinate changes can affect records close to a radius threshold.

## 4. Database design and query methods

The demonstration uses a dedicated `d_project` schema. Its `facilities` table has a primary key, a controlled eight-category vocabulary, provenance fields, a non-null `geometry(Point,4326)` column and geometry validity checks. A GiST index on `geom::geography` matches the expression used by the radius predicate. Query functions access a small `facilities_input` view, allowing the same logic to be connected to the group's final Facilities table without rewriting the queries. This contribution does not replace the required group-wide HK_Admin and census design.

### 4.1 Q1 - Nearest recorded facility

For a query point p, the nearest facility minimizes the WGS84 spheroidal distance d(p,f) over every facility in the input. The implementation uses `ST_Distance` on geography values and orders by the unrounded distance. A unique facility ID resolves exact ties deterministically; rounding is applied only for display. The returned fields identify the facility, category, district, address and distance.

```sql
SELECT facility_id, facility_name, facility_type, district,
       round(distance_m::numeric, 3) AS distance_m
FROM d_project.nearest_facility(114.1795, 22.3048);
```

The function performs an exact full-snapshot distance ordering. At 775 records, this is transparent and practical. It avoids claiming that a limited approximate nearest-neighbour shortlist necessarily contains the exact spheroidal minimum. For larger deployments, an optimized search should preserve and verify the same distance definition.

### 4.2 Q2 - Types within an assumed walking-distance threshold

The primary threshold is 500 m. At an assumed walking speed of 1.2 m/s, a direct path of this length would take approximately 6.9 minutes. This is a study assumption, not a cited universal planning standard or a computed travel time. Because a pedestrian network is unavailable, the query measures straight-line geographic proximity to facility reference points.

`ST_DWithin` selects facilities at or within the radius, using geography units in metres. The summary reports both the number of records and `COUNT(DISTINCT facility_type)`. It also lists the types so that the count is interpretable. A no-match location returns zero counts and an empty type array rather than disappearing from the output.

```sql
SELECT facility_count, type_count, facility_types
FROM d_project.nearby_summary(114.1795, 22.3048, 500);
```

Separate detail output identifies each contributing facility and its distance. Input validation rejects null, out-of-range or non-finite coordinates and negative or non-finite radii. Longitude is always supplied before latitude. An empty facility input returns no nearest record and a zero-count radius summary.

## 5. Results and interpretation

The four locations below are deliberately defined study points. Their coordinates are the reproducibility specification; their labels indicate general areas and do not imply verified entrances or exact landmark positions.

| ID and area | Longitude | Latitude | Nearest recorded facility | Distance (m) |
| --- | --- | --- | --- | --- |
| Q01 Hung Hom | 114.1795 | 22.3048 | Hong Tat Path Garden | 432.969 |
| Q02 Central | 114.1594 | 22.2819 | Hong Kong Park Sports Centre | 504.675 |
| Q03 Sha Tin | 114.1889 | 22.3810 | Sha Tin Park | 194.799 |
| Q04 Tung Chung | 113.9411 | 22.2890 | Tung Chung Swimming Pool | 257.595 |

Q01's nearest record belongs to Basketball Courts, Q02's to Fitness Rooms, Q03's to Parks, Zoos and Gardens, and Q04's to Swimming Pools. Their reported districts are YAU TSIM MONG, CENTRAL & WESTERN, SHA TIN and ISLANDS respectively.

| Study point | Records within 500 m | Distinct types within 500 m | Included types |
| --- | --- | --- | --- |
| Hung Hom | 1 | 1 | Basketball |
| Central | 0 | 0 | None |
| Sha Tin | 5 | 4 | Badminton; basketball; fitness; parks |
| Tung Chung | 5 | 4 | Badminton; basketball; fitness; swimming |

Sha Tin and Tung Chung have the same record and type counts at 500 m, but different activity mixes. This shows why listing categories is more informative than reporting a count alone. Five records correspond to four types because repeated facilities of the same type do not add another category.

Central's zero result does not mean that Central lacks facilities. The nearest reference point lies only 4.7 m beyond the assumed threshold. This is a particularly sensitive classification, given that source points are not verified entrances and source coordinate representations can differ. Threshold results should therefore be reported with distances and a sensitivity check.

### 5.1 Radius sensitivity

| Study point | Types at 400 m | Types at 500 m | Types at 800 m |
| --- | --- | --- | --- |
| Hung Hom | 0 | 1 | 1 |
| Central | 0 | 0 | 4 |
| Sha Tin | 1 | 4 | 6 |
| Tung Chung | 4 | 4 | 5 |

![Distinct types by radius](../results/radius_sensitivity.png)

Increasing the radius never decreases the record or type count. Central changes from zero to four types between 500 and 800 m; Sha Tin changes from one to six types between 400 and 800 m. Tung Chung's four-type count is stable between 400 and 500 m. These contrasts demonstrate that the threshold materially affects the interpretation. The analysis does not establish that one whole district is better served than another.

![Local facility maps](../results/location_maps.png)

The maps show facility reference points, selected study points, and approximate 500 m and 800 m display rings in Hong Kong Grid coordinates. The numerical inclusion tests use WGS84 geodesic distance. Co-located activity records can overlap on the map; the detail CSV provides the complete list. The gray lines come from the instructor-provided district polygon layer, not from a routable street network.

## 6. Verification and reproducibility

The package contains two independently executable calculation paths: PostGIS SQL and a Python reference based on PROJ's WGS84 geodesic calculations. Database verification compares all four nearest IDs and distances, plus all twelve combinations of study point and radius. Distance agreement is checked within 0.002 m of the independently rounded reference values; this tolerance is for implementation checking, not a claim about source accuracy.

Synthetic SQL tests check zero distance, deterministic tie handling, multiple categories at a shared point, repeated facilities of one category, inclusive boundary behaviour, an outside-radius point, no matches, invalid inputs and an empty facility table. Fixture data and the temporary input-view change are rolled back. Additional Python checks verify unique identifiers, eight-category coverage, self-distances, threshold membership and monotonic counts.

The scripts were executed successfully using PostgreSQL 17.11 and PostGIS 3.6.2. All 11 regression scenarios passed, and all four nearest results and twelve radius scenarios matched the independent reference. Actual database outputs and execution evidence are retained in `results/*_postgis.csv` and `results/database_validation.txt`. The SQL files, English source snapshots, source manifest, query-location CSV and result files form the reproducible analytical record. The detailed execution order and integration instructions are in `README.md`.

## 7. Limitations and conclusion

This analysis measures proximity to official recorded facility points. Actual walking accessibility depends on entrances, roads, crossings, footbridges, slopes and water barriers. Country Park reference points are particularly limited substitutes for entry locations or park footprints. A future network-based analysis should connect verified entrances to a pedestrian graph and use travel distance or travel time.

The official datasets are not a complete inventory of every private, informal or temporarily available sporting opportunity. A record does not establish opening status, booking availability, cost, accessibility for disabled users, capacity or service quality. The snapshot combines datasets with different update histories, which are preserved in the provenance information. Four selected points cannot establish population-level equity, use patterns or causal health benefits.

Within those limits, the two queries provide clear, reproducible answers. Exact distance ranking identifies the nearest recorded opportunity, while distinct-category counting describes local variety. The sensitivity results demonstrate why a single radius should not be interpreted as a definitive accessibility boundary. D's contribution is ready to be connected to the team's agreed Facilities schema, with the two park boundary discrepancies explicitly retained for reconciliation.

## References and data attribution

- AFCD and LCSD. Official facility datasets, retrieved 3 November 2026 through the Common Spatial Data Infrastructure (CSDI) Portal. Eight dataset identifiers, version-specific download URLs and SHA-256 values are provided in `data/source_manifest.json`.
- CSDI Portal. Terms and conditions and data-source attribution: https://portal.csdi.gov.hk/csdi-webpage/doc/TNC
- AFCD. Country Parks metadata: https://portal.csdi.gov.hk/csdi-webpage/metadata/afcd_rcd_1635129924112_81508/html
- LCSD. Parks, Zoos and Gardens metadata: https://portal.csdi.gov.hk/csdi-webpage/metadata/lcsd_rcd_1629267205215_19292/html
- LSGI3245. Final Project Instruction, 2026/27 Semester 1, and instructor-provided HKDistrict18 shapefile.
- PostGIS. ST_Distance: https://postgis.net/docs/ST_Distance.html
- PostGIS. ST_DWithin: https://postgis.net/docs/ST_DWithin.html
- PostGIS. ST_Transform: https://postgis.net/docs/ST_Transform.html
- PostGIS. ST_Covers: https://postgis.net/docs/ST_Covers.html

Facility data from the Government of the Hong Kong SAR via the CSDI Portal is used under the portal's terms and conditions. Figures and analytical results were produced for this project from the cited sources.
