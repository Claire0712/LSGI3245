# Verification Evidence

Validation date: 3 November 2026 (Hong Kong time).

## Database execution

- PostgreSQL 17.11, 64-bit Windows.
- PostGIS 3.6.2; database-side PROJ 8.2.1.
- All setup, load, function, required-query, batch and sensitivity scripts executed successfully with psql's `ON_ERROR_STOP` enabled.
- 775 facility records loaded, covering all eight assignment categories.
- 11 synthetic regression scenarios passed. All fixture changes were rolled back.
- Four nearest IDs/distances and twelve radius-count scenarios matched the independent geodesic reference. Nearest-distance comparison tolerance: 0.002 m relative to the rounded reference values.
- The temporary database server was bound to localhost for verification and stopped after result export. No Windows service was installed.

Full execution evidence: `database_validation.txt`.

## Direct database exports

| File | Rows | Content |
| --- | --- | --- |
| q1_nearest_postgis.csv | 4 | Nearest facility, type, district and distance for each input point. |
| q2_summary_postgis.csv | 4 | Record and distinct-type counts at 500 m. |
| q2_detail_postgis.csv | 11 | Every facility record contributing to the four 500 m summaries. |
| radius_sensitivity_postgis.csv | 12 | Record and type counts for four locations at 400, 500 and 800 m. |

## Independent reference and data checks

The Python reference uses PROJ's WGS84 geodesic calculation through pyproj. Reference outputs are labelled `_reference.csv` and are not presented as database exports. All checks in `reference_checks.csv` passed.

Cleaning counts: 25 Country Parks and 124 Parks, Zoos and Gardens records; 149 D records in total. No records were rejected and no exact duplicates were removed. Source input checksums are verified before processing. The audit retains 186 coordinate-representation differences over 5 m and five provider-versus-polygon district review flags across all eight types. Two of the district flags concern D's park records; no coordinate-representation differences over 5 m concern D's two categories.

Passing implementation tests verifies the calculation and handling of the supplied inputs. It does not establish that every source point is an entrance, that the boundary layer is current, or that straight-line distances equal walking routes. These limitations are stated in the report.
