# 给组员 E 的交接与作图指南（Part B -> Part E）

这份最终版压缩包（`B_Deliverables.zip`）已将全组 A（422 条）、B（99 条）、C（111 条）、D（149 条）共 **781 条**运动与户外设施主表及 Q1–Q4 参考结果全部对齐并核验完毕。你可以直接使用以下文件完成你的区域比较、图表制作、结论汇总与排练组织：

## 1. 你直接需要用到的核心文件

| 文件路径 | 内容说明 | 使用建议 |
| :--- | :--- | :--- |
| `results/e_q3_district_counts_ranked.csv` | **Q3 各行政区设施数量排名表**：包含全部类别总计（`ALL_8_TYPES_TOTAL`）及 8 个单独类别（共 9 组 × 18 区 = 162 行），已按**设施数量降序**排列，完整保留数量为 0 的行政区。 | 直接用于制作 Q3 各区设施数量对比柱状图 / 分级统计地图（Choropleth Map）。 |
| `results/e_q4_district_per_capita_ranked.csv` | **Q4 各行政区人均设施排名表**：包含全部类别总计及 8 个单独类别（共 9 组 × 18 区 = 162 行），已按**人均拥有量（及每十万人拥有量 `per_100k_strict`）降序**独立排列，完整保留 0 值区。 | 直接用于制作 Q4 各区每十万人设施数量对比图。 |
| `sql/05_q3_q4_district_queries_for_e.sql` | **Q3 与 Q4 的标准 PostGIS 查询脚本**：使用 `LEFT JOIN` 保留零设施区，使用 `LEFT JOIN public.census` 与 `ORDER BY ... DESC NULLS LAST` 防止丢区，同时提供**严格 `ST_Covers` 版**与 **15 米海岸线容差版**。 | 用于在本地 PostgreSQL 数据库实测运行及提交最终 SQL 代码包。 |
| `results/d_queries_on_781_comparison.csv` | **D 部分四个测试点在 781 主表上的结果表**：红磡（`432.969 m`，500m 内 1 类）、中环（*Hong Kong Park Sports Centre* `Badminton Court` `509.481 m`，500m 内 0 类 / 800m 内 4 类）、沙田（`194.799 m`，500m 内 4 类）、东涌（`257.595 m`，500m 内 4 类）。 | 用于整合前两类位置查询（Q1/Q2）与后两类区域查询（Q3/Q4）的图表和总结。 |
| `results/b_spatial_audit_figure.png` | **B 部分三联高清汇总图**：含 8 类设施总数分布（781 条）、坐标偏差分布及全港 781 点空间覆盖底图。 | 可供参考或放入 PPT 展示。 |

## 2. 作图与撰写结论时必须留意的 3 个关键细节（拿高分避坑点）

1. **严格空间匹配（779 条）vs. 15 米海岸线容差（781 条）的口径说明**：
   - 在全部 8 类设施中，有 **7 类设施**（羽毛球、篮球、网球、游泳池、健身室、运动场、郊野公园）在严格 `ST_Covers` 和 15 米容差下的各区数量 **100% 完全相同**。
   - 只有 D 负责的 **`Parks, Zoos and Gardens`（共 124 条）** 有 2 个海滨公园位于课程底图 `HKDistrict18.shp` 海岸线外侧：
     - *Tsing Bik Sitting-out Area*（距 `Tuen Mun` 多边形边界 `0.380 m`）
     - *East Coast Park (Phase 1)*（距 `Eastern` 多边形边界 `10.946 m`，提供方文本列标为 `Wan Chai`）
   - 在我给你的 `e_q3` 和 `e_q4` 表中，**同时列出了 `facility_count_strict_st_covers`（严格匹配，共 779 条）和 `facility_count_tolerance_15m`（15m 容差匹配，共 781 条）两列及对应每十万人指标**。无论你选哪一列画图都可以，只需在图注和报告中明确写出一句：*“严格多边形覆盖匹配 779 条记录；其余 2 条海滨公园记录位于边界外 0.38 m 与 10.95 m，在容差估计列中列出”*，不能把容差估计直接混同为已证实的法定区属。
2. **保留零设施行政区（0-Count Districts）**：
   - 画特定类别的 18 区柱状图或排名表时，务必保留数量为 0 的行政区（例如：网球场在 `Central and Western` 为 0；运动场在 `Central and Western` 和 `Yau Tsim Mong` 为 0；郊野公园在九龙 5 区及 `Kwai Tsing` 共 6 个高密度城区为 0）。这正是体现 `LEFT JOIN` 价值的重点。
3. **人口年份与人均单位说明**：
   - C 提供的 `census` 表来自课程下发的 **2021 年人口普查数据**（全港陆地总人口 `7,411,945`）。虽然老师 PDF 说明中写的是推荐 2016，但实际课程文件为 2021，请在报告和 PPT 图注中统一标明 **“2021 Population Census”**，人均指标建议展示 **`per_100k_strict`（每十万人拥有设施数）**，数值更直观易读。
