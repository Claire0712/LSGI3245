# Part B — Three-Minute Presentation (Data Cleaning & Unified `Facilities` Table)

LSGI3245 Geospatial Database Management and Design | 2026/27 Semester 1

Use four slides within the group presentation template (following Member A's opening and preceding Member C's schema design section). The spoken script is **338 words**, timed for **3 minutes** including slide transitions.

## Slide 1 — Standardizing Eight Facility Feeds into One Unified Schema

**Suggested time: 0:00–0:45**

Slide content:

- Part B cleaning scope: 53 Tennis Courts + 46 Swimming Pools (99 records; 0 rejected; 0 exact duplicates).
- Team-wide consolidation: 781 facility records across all 8 categories (A = 422, B = 99, C = 111, D = 149).
- Coordinate normalization to WGS84 (`EPSG:4326`):
  - Source WGS84 geometry retained for Tennis, Badminton, and Basketball.
  - Hong Kong 1980 Grid (`EPSG:2326`) transformed to `EPSG:4326` for Swimming Pools, Country Parks, and Parks/Zoos/Gardens.
  - Audited DMS coordinates converted to decimal `EPSG:4326` for Fitness Rooms and Sports Grounds.

Speaker script:

Thank you. My part covers cleaning the Tennis Court and Swimming Pool datasets, and consolidating all eight facility categories into our unified `Facilities` table in PostgreSQL and PostGIS. Across the raw datasets, we addressed three practical issues: bilingual and HTML-formatted text fields, inconsistent category labels across team members, and three different coordinate representations. For my two categories, I cleaned fifty-three Tennis Court records and forty-six Swimming Pool records. While Tennis Courts supplied WGS84 geometry coordinates directly, Swimming Pools stored geometry in the Hong Kong 1980 Grid, EPSG 2326, which I transformed into WGS84 decimal degrees. Combining the verified handoffs from Members A, B, C, and D yields seven hundred and eighty-one facility records under a single eight-category naming standard.

## Slide 2 — Coordinate Provenance Audit: Source Geometry vs. Tabular Attributes

**Suggested time: 0:45–1:30**

Slide content:

- Audit rule: retain source GIS geometry (`Geometry*` fields) and log offsets > 5 m against tabular `LATITUDE`/`LONGITUDE` rather than deleting valid venues.

| Dataset (Part B) | Input Rows | Retained | Offset > 5 m | Max Offset | Largest Discrepancy Example |
| :--- | :---: | :---: | :---: | :---: | :--- |
| Tennis Courts | 53 | 53 | 23 (43.4%) | 25.60 m | North Kwai Chung Tang Shiu Kin Sports Centre |
| Swimming Pools | 46 | 46 | 6 (13.0%) | 54.31 m | Kowloon Park Pool (54.31 m); Tung Chung Pool (53.34 m) |

Speaker script:

Rather than assuming a single coordinate column is error-free or deleting records with minor discrepancies, we compared the embedded GIS geometry against the tabular latitude and longitude attributes using WGS84 geodesic distance. Using a five-metre review threshold, twenty-three Tennis Court records and six Swimming Pool records showed offsets above five metres. In Tennis Courts, the largest offset is twenty-five point six metres at North Kwai Chung Tang Shiu Kin Sports Centre. In Swimming Pools, Kowloon Park Swimming Pool and Tung Chung Swimming Pool differ by more than fifty-three metres between their geometry and attribute columns. Following our group provenance rule, we retained the source geometry coordinates and recorded all offsets in an audit table.

## Slide 3 — Implementing `public.facilities` and Dual Spatial Indexes

**Suggested time: 1:30–2:15**

Slide content:

- Non-destructive table creation (`CREATE TABLE IF NOT EXISTS`) and idempotent upsert load (`1..781`).
- Point geometry constructed via `ST_SetSRID(ST_MakePoint(longitude, latitude), 4326)` (X = longitude, Y = latitude).
- Schema constraints: single canonical `facility_type` list, Hong Kong bounding box (`22.10°–22.60° N`, `113.80°–114.50° E`), and `ST_IsValid(geom)`.
- Dual GiST indexes: `USING gist (geom)` for polygon joins and `USING gist ((geom::geography))` for metre-based proximity queries.

Speaker script:

In Task 2, I implemented the unified `public.facilities` table in PostgreSQL and PostGIS. Each of the seven hundred and eighty-one records has a unique primary key, and its spatial column is generated as an EPSG 4326 Point using `ST_SetSRID(ST_MakePoint(longitude, latitude), 4326)`, strictly placing longitude first as X and latitude second as Y. At the database level, check constraints enforce a single canonical list of eight category names—preventing singular and plural duplicates—along with Hong Kong coordinate bounds and geometry validity. We also created both a geometry GiST index for district polygon joins and a functional geography GiST index for metre-based proximity queries.

## Slide 4 — Spatial Location Check Against `HK_Admin` Polygons

**Suggested time: 2:15–3:00**

Slide content:

- Use `results/b_spatial_audit_figure.png` as the slide visual.
- Strict polygon coverage (`ST_Covers`): **779 of 781 records (99.74%)** fall inside a single `HK_Admin` polygon (100% of A, B, and C records).
- Two coastal park points outside polygons (original coordinates preserved):
  - *Tsing Bik Sitting-out Area* (`22.3772762, 113.9803686`): 0.380 m from `Tuen Mun`.
  - *East Coast Park (Phase 1)* (`22.2879294, 114.1891845`): 10.946 m from `Eastern`.
- Four provider-versus-polygon district differences logged (`Victoria Park` Basketball, Tennis, and Swimming Pool; `Lei Yue Mun Basketball Court`).

Speaker script:

Finally, I checked all seven hundred and eighty-one facility points against the eighteen `HK_Admin` polygons using `ST_Covers`. Seven hundred and seventy-nine points—including all records cleaned by Members A, B, and C—are strictly covered by a single district polygon. Two waterfront parks in Member D's dataset, Tsing Bik Sitting-out Area and East Coast Park Phase 1, lie zero point three eight metres and ten point nine five metres outside the supplied polygon boundary. We preserved their original coordinates in the table so distance queries are unaffected, and flagged them explicitly in our district-matching view. Four records also had provider district text that differed from the polygon match, such as Victoria Park and Lei Yue Mun. Member C will now introduce the three-table schema and relationships.

## Anticipated Q&A for Member B

**Why did you enforce a single canonical `facility_type` vocabulary in the table constraint?**
If singular and plural labels for the same category coexist in `public.facilities`, a query using `COUNT(DISTINCT facility_type)` can double-count categories. Enforcing a single eight-value constraint guarantees exactly eight distinct types, while our integration view maps them one-to-one for scripts expecting plural labels.

**Did you move the two coastal park points to make `ST_Covers` match 100%?**
No. Moving points alters source coordinates and could affect distance queries. We kept the original coordinates in `public.facilities` and used a `LEFT JOIN LATERAL` view that preserves all 781 rows while explicitly labelling the two coastal parks as `Tolerance_15m_Estimate`.

**Why does Central's nearest facility change from Fitness Rooms (504.675 m) in D's 775-row snapshot to Badminton Court (509.481 m) in the 781-row master table?**
Member C's Fitness Room dataset comes from the LCSD JSON feed, which records coordinates in integer arcseconds (`22-16-38, 114-09-33`, or `22.2772222, 114.1591667`, 518.550 m from the Central study point), whereas D's 775-row snapshot used a GDB decimal coordinate (`504.675 m`). At the same venue (`Hong Kong Park Sports Centre`), Member A's Badminton Court record is 509.481 m away and therefore becomes the nearest record in the 781-row table. The 500 m (0 types) and 800 m (10 records, 4 types) results remain unchanged.
