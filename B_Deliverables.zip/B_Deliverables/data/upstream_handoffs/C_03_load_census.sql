INSERT INTO public.census
    (district_name, population, population_percentage, census_year)
VALUES
    ('Central and Western', 235953, 3.183415, 2021),
    ('Wan Chai', 166695, 2.249005, 2021),
    ('Eastern', 529603, 7.145263, 2021),
    ('Southern', 263278, 3.552077, 2021),
    ('Yau Tsim Mong', 310647, 4.191167, 2021),
    ('Sham Shui Po', 431090, 5.816152, 2021),
    ('Kowloon City', 410634, 5.540165, 2021),
    ('Wong Tai Sin', 406802, 5.488465, 2021),
    ('Kwun Tong', 673166, 9.082177, 2021),
    ('Kwai Tsing', 495798, 6.689175, 2021),
    ('Tsuen Wan', 320094, 4.318624, 2021),
    ('Tuen Mun', 506879, 6.838677, 2021),
    ('Yuen Long', 668080, 9.013559, 2021),
    ('North', 309631, 4.177459, 2021),
    ('Tai Po', 316470, 4.269729, 2021),
    ('Sha Tin', 692806, 9.347155, 2021),
    ('Sai Kung', 489037, 6.597958, 2021),
    ('Islands', 185282, 2.499776, 2021)
ON CONFLICT (district_name) DO UPDATE
SET population = EXCLUDED.population,
    population_percentage = EXCLUDED.population_percentage,
    census_year = EXCLUDED.census_year;
