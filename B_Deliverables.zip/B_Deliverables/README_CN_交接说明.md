# B 部分修订说明（针对组员 D 审查意见的逐项闭环）

本版本（v2）已将组员 D 提出的全部 8 项审查建议 100% 修正并完成程序化校验：

1. **移除 `DROP ... CASCADE` 与 `TRUNCATE ... CASCADE`（解决数据库覆盖风险）**：
   - `sql/01_create_facilities_table.sql` 改为非破坏性的 `CREATE TABLE IF NOT EXISTS public.facilities` 和 `CREATE INDEX IF NOT EXISTS`。
   - `sql/02_load_facilities_781.sql` 采用临时表 `facilities_expected_781` + 全字段逐条比对保护：仅当 `public.facilities` 为空表时执行插入；若表非空，则逐条核对全部 7 个字段（`facility_id, facility_type, facility_name, address, latitude, longitude, geom`），只有 781 条记录全字段 100% 匹配时才作为重复运行跳过，否则立即 `RAISE EXCEPTION` 报错停止，彻底杜绝静默跳过或混入不同数据。
2. **空间审计表与 781 主表坐标 100% 逐位一致（解决 4 条审计坐标不一致问题）**：
   - `results/all_781_spatial_audit_issues.csv` 现由 `scripts/clean_and_consolidate_b.py` 直接从 `Facilities_master_781_audited.csv` 按 `facility_id` 动态提取生成，并在脚本内通过 `assert` 強制校验 `facility_id`、`facility_type`、`facility_name`、`latitude`、`longitude` 与主表完全相等（精确到小数点后 7 位）：
     - `facility_id = 228` (*Lei Yue Mun Basketball Court*): `22.2881000, 114.2373000`
     - `facility_id = 402` (*Victoria Park*, `Basketball Court`): `22.2826000, 114.1882000`
     - `facility_id = 471` (*Victoria Park*, `Tennis Court`): `22.2826000, 114.1882000`
     - `facility_id = 601` (*East Coast Park (Phase 1)*, `Parks, Zoos and Gardens`): `22.2879294, 114.1891845`
     - `facility_id = 687` (*Tsing Bik Sitting-out Area*, `Parks, Zoos and Gardens`): `22.3772762, 113.9803686`
     - `facility_id = 779` (*Victoria Park Swimming Pool*, `Swimming Pool`): `22.2833358, 114.1904757`
   - 同时采纳 D 的建议，在报告和讲稿中移除了未经压缩包材料独立证实的“2016 选区调整”归因表述，改为严谨客观的：*“提供方文本区名与课程边界图层空间匹配结果不一致，保留原始几何坐标并记录待核实”*。
3. **保留海滨公园原始坐标，并将关联视图改为 `LEFT JOIN LATERAL`**：
   - 彻底移除任何修改原始坐标的语句，`public.facilities` 100% 保留 781 条记录的原始几何坐标。
   - `sql/04_team_integration_and_views.sql` 中的 `public.v_facilities_with_district` 改用 `LEFT JOIN LATERAL`，同时输出 `district_name_strict`（严格 `ST_Covers`）与 `district_name_with_15m_tolerance`（15m 容差估计），并用 `district_match_method` 明确标记 `'ST_Covers_Exact'`（779 条）与 `'Tolerance_15m_Estimate'`（2 条），即便有超出 15m 的点也绝不会从视图中消失。
4. **严格统一单一 `facility_type` 标准，杜绝单复数混用**：
   - 包内只保留唯一一套主表 `data/Facilities_master_781.csv`，且 `01_create_facilities_table.sql` 的 `CHECK` 约束只允许唯一的 8 个标准类名（`Badminton Court`、`Basketball Court`、`Tennis Court`、`Country Park`、`Fitness Room`、`Parks, Zoos and Gardens`、`Sports Ground`、`Swimming Pool`），彻底杜绝 `COUNT(DISTINCT facility_type)` 把单复数算成两类的风险。
   - 在 `04_team_integration_and_views.sql` 的 `d_project.facilities_input` 视图中提供一对一复数映射，完全兼容 D 的函数。
5. **查明中环（Q02）最近设施从 `504.675 m` 变为 `509.481 m` 的确切技术原因**：
   - D 原 775 条演示库中的 `fitness.csv` 使用 CSDI GDB 小数坐标 `(114.1593152, 22.2773487)`，距 Q02 为 `504.675 m`；
   - C 交接的 86 条健身室来自 LCSD JSON 源数据（`facility-fitrm.json`），其原始坐标为整秒度分秒 `22-16-38, 114-09-33`（即 `22.2772222, 114.1591667`），因 1 角秒取整向西南偏移约 20 米，距 Q02 变为 `518.550 m`，从而使同一场馆（*Hong Kong Park Sports Centre*）内的 `Badminton Court`（`22.2773000, 114.1593000`，距 Q02 `509.481 m`）成为第 1 近记录。400m/500m/800m 范围内的设施数与种类数（500m 为 0/0，800m 为 10/4）完全不变。
6. **为 E 拆分独立的 Q3（按数量排序）与 Q4（按人均排序）预览表及参考 SQL**：
   - 新增按设施数量降序排列的 `results/e_q3_district_counts_ranked.csv`、按人均数量降序排列的 `results/e_q4_district_per_capita_ranked.csv`（均保留 0 设施行政区并同时列出严格匹配值与 15m 容差值），以及配套 SQL `sql/05_q3_q4_district_queries_for_e.sql`。
7. **清洗脚本 100% 相对路径可独立复现**：
   - 所有上游输入（`data/source/` 及 `data/upstream_handoffs/`）已完整打包在 ZIP 内；`scripts/clean_and_consolidate_b.py` 与 `scripts/make_figures_b.py` 仅使用相对路径 `Path(__file__).resolve().parents[1]`，在任何电脑解压后直接运行即可完整重建所有输出。
8. **修复 Markdown 转义字符并统一英文正式文档**：
   - 修复了 `docs/B_Report_Section.md` 中的制表符/回车符转义问题；`README.md`、`docs/B_Report_Section.md`、`presentation/B_Slides_and_Script.md` 及全部 SQL 注释均为全英文正式交付格式。
