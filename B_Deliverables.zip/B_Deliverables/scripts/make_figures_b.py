#!/usr/bin/env python3
"""
Generate high-resolution visual figure results/b_spatial_audit_figure.png
using purely relative paths inside B_Deliverables.

Run from anywhere:
    python3 scripts/make_figures_b.py
"""
import csv
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from shapely.geometry import shape

ROOT = Path(__file__).resolve().parents[1]


def main():
    master_rows = list(csv.DictReader((ROOT / "data/Facilities_master_781_audited.csv").open(encoding="utf-8")))
    tennis_cleaned = list(csv.DictReader((ROOT / "data/Tennis_Courts_cleaned.csv").open(encoding="utf-8")))
    swimming_cleaned = list(csv.DictReader((ROOT / "data/Swimming_Pools_cleaned.csv").open(encoding="utf-8")))

    plt.rcParams["font.sans-serif"] = ["DejaVu Sans"]
    plt.rcParams["axes.edgecolor"] = "#334155"
    plt.rcParams["axes.linewidth"] = 0.8

    fig = plt.figure(figsize=(16.5, 5.8), dpi=220)
    fig.patch.set_facecolor("#FFFFFF")
    gs = fig.add_gridspec(1, 3, width_ratios=[1.1, 1.1, 1.35], wspace=0.28, left=0.135, right=0.975, top=0.83, bottom=0.13)

    # Panel A
    ax1 = fig.add_subplot(gs[0, 0])
    cats_order = [
        ("Basketball Court [A]", 306, "#1E40AF"),
        ("Parks, Zoos & Gardens [D]", 124, "#15803D"),
        ("Badminton Court [A]", 116, "#2563EB"),
        ("Fitness Room [C]", 86, "#0F766E"),
        ("Tennis Court [B]", 53, "#D97706"),
        ("Swimming Pool [B]", 46, "#EA580C"),
        ("Sports Ground [C]", 25, "#0D9488"),
        ("Country Park [D]", 25, "#16A34A"),
    ][::-1]
    y_pos = np.arange(len(cats_order))
    vals = [c[1] for c in cats_order]
    cols = [c[2] for c in cats_order]
    bars = ax1.barh(y_pos, vals, color=cols, height=0.62, edgecolor="none", alpha=0.92)
    ax1.set_yticks(y_pos)
    ax1.set_yticklabels([c[0] for c in cats_order], fontsize=9.2, fontweight="bold", color="#1E293B")
    ax1.set_xlabel("Cleaned Facility Records (Total = 781)", fontsize=9.5, fontweight="bold", color="#334155")
    ax1.set_xlim(0, 360)
    ax1.grid(axis="x", linestyle="--", alpha=0.35, color="#94A3B8")
    ax1.set_axisbelow(True)
    ax1.spines["top"].set_visible(False)
    ax1.spines["right"].set_visible(False)
    for bar, v in zip(bars, vals):
        ax1.text(v + 6, bar.get_y() + bar.get_height() / 2, f"{v}", va="center", ha="left", fontsize=9, fontweight="bold", color="#0F172A")
    ax1.set_title("A. Consolidated Facilities (n = 781)", fontsize=10.8, fontweight="bold", color="#0F172A", pad=12, loc="left")

    # Panel B
    ax2 = fig.add_subplot(gs[0, 1])
    t_diffs = sorted([float(r["coordinate_difference_m"]) for r in tennis_cleaned], reverse=True)
    s_diffs = sorted([float(r["coordinate_difference_m"]) for r in swimming_cleaned], reverse=True)
    ax2.plot(range(1, len(t_diffs) + 1), t_diffs, marker="o", markersize=3.8, linewidth=1.8, color="#D97706", label="Tennis Courts (n=53, 23 > 5m)")
    ax2.plot(range(1, len(s_diffs) + 1), s_diffs, marker="s", markersize=3.8, linewidth=1.8, color="#EA580C", label="Swimming Pools (n=46, 6 > 5m)")
    ax2.axhline(5.0, color="#DC2626", linestyle="--", linewidth=1.2, label="5.0 m Audit Threshold")
    ax2.annotate("Kowloon Park Pool (54.31 m)", xy=(1, s_diffs[0]), xytext=(6.5, 55.2),
                 arrowprops=dict(arrowstyle="->", color="#9A3412", lw=1.0), fontsize=8.3, fontweight="bold", color="#9A3412")
    ax2.annotate("Tung Chung Pool (53.34 m)", xy=(2, s_diffs[1]), xytext=(8.5, 43.5),
                 arrowprops=dict(arrowstyle="->", color="#9A3412", lw=1.0), fontsize=8.3, fontweight="bold", color="#9A3412")
    ax2.annotate("N. Kwai Chung Tennis (25.60 m)", xy=(1, t_diffs[0]), xytext=(9.0, 24.5),
                 arrowprops=dict(arrowstyle="->", color="#B45309", lw=1.0), fontsize=8.3, fontweight="bold", color="#B45309")
    ax2.set_xlabel("Facility Rank by Discrepancy", fontsize=9.5, fontweight="bold", color="#334155")
    ax2.set_ylabel("Geometry vs Attribute Offset (m)", fontsize=9.5, fontweight="bold", color="#334155")
    ax2.set_ylim(-2, 62)
    ax2.set_xlim(0, 56)
    ax2.grid(True, linestyle="--", alpha=0.35, color="#94A3B8")
    ax2.spines["top"].set_visible(False)
    ax2.spines["right"].set_visible(False)
    ax2.legend(loc="center right", bbox_to_anchor=(0.99, 0.56), fontsize=8.0, frameon=True, facecolor="#F8FAFC", edgecolor="#CBD5E1")
    ax2.set_title("B. Source Geometry vs Attribute Offset", fontsize=10.8, fontweight="bold", color="#0F172A", pad=12, loc="left")

    # Panel C
    ax3 = fig.add_subplot(gs[0, 2])
    districts_geojson = json.loads((ROOT / "data/upstream_handoffs/districts.geojson").read_text(encoding="utf-8"))
    for feat in districts_geojson["features"]:
        geom = shape(feat["geometry"])
        geoms = geom.geoms if hasattr(geom, "geoms") else [geom]
        for poly in geoms:
            x, y = poly.exterior.xy
            ax3.fill(x, y, facecolor="#F1F5F9", edgecolor="#64748B", linewidth=0.55, zorder=1)

    other_rows = [r for r in master_rows if r["member_owner"] != "B" and r["spatial_match_status"] == "ST_Covers_Exact"]
    b_rows_map = [r for r in master_rows if r["member_owner"] == "B"]
    coastal_rows = [r for r in master_rows if r["spatial_match_status"] != "ST_Covers_Exact"]

    ax3.scatter(
        [float(r["longitude"]) for r in other_rows],
        [float(r["latitude"]) for r in other_rows],
        s=9, c="#3B82F6", alpha=0.55, label="A/C/D Covered by HK_Admin (680)", zorder=2
    )
    ax3.scatter(
        [float(r["longitude"]) for r in b_rows_map],
        [float(r["latitude"]) for r in b_rows_map],
        s=22, c="#EA580C", edgecolors="#FFFFFF", linewidths=0.4, alpha=0.95, label="B Tennis & Swimming Covered (99)", zorder=3
    )
    ax3.scatter(
        [float(r["longitude"]) for r in coastal_rows],
        [float(r["latitude"]) for r in coastal_rows],
        s=58, c="#DC2626", marker="*", edgecolors="#7F1D1D", linewidths=0.6, label="Outside Polygon: 0.38m & 10.95m (2)", zorder=4
    )
    ax3.set_xlim(113.82, 114.45)
    ax3.set_ylim(22.14, 22.56)
    ax3.set_xlabel("Longitude (EPSG:4326)", fontsize=9.5, fontweight="bold", color="#334155")
    ax3.set_ylabel("Latitude (EPSG:4326)", fontsize=9.5, fontweight="bold", color="#334155")
    ax3.spines["top"].set_visible(False)
    ax3.spines["right"].set_visible(False)
    ax3.legend(loc="lower right", fontsize=7.8, frameon=True, facecolor="#FFFFFF", edgecolor="#CBD5E1")
    ax3.set_title("C. Spatial Check on HK_Admin (779/781 Covered)", fontsize=10.8, fontweight="bold", color="#0F172A", pad=12, loc="left")

    fig.suptitle(
        "LSGI3245 Part B — Data Cleaning, Unified Facilities Table (n = 781) & PostGIS Spatial Validation",
        fontsize=13.2, fontweight="bold", color="#0F172A", y=0.95
    )
    fig.savefig(ROOT / "results/b_spatial_audit_figure.png", dpi=220)
    plt.close(fig)
    print("Saved results/b_spatial_audit_figure.png")


if __name__ == "__main__":
    main()
