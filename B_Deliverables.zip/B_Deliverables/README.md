# Part B — Data Cleaning, Unified `Facilities` Table, and Spatial Validation

LSGI3245 Geospatial Database Management and Design | 2026/27 Semester 1

This package contains Member B's complete deliverables: cleaned Tennis Court (53 rows) and Swimming Pool (46 rows) datasets, the consolidated 781-record `Facilities` master dataset combining Members A, B, C, and D, non-destructive PostgreSQL/PostGIS setup and validation scripts, cross-checked spatial audit results, presentation materials, and report text.

## 1. Key Package Files

| File or Folder | Purpose |
| :--- | :--- |
| `scripts/clean_and_consolidate_b.py` | Standalone, relative-path Python script that verifies SHA-256 hashes, cleans Part B data, consolidates all 781 records, runs spatial checks, and generates the SQL and result CSVs. |
| `scripts/make_figures_b.py` | Standalone, relative-path script that regenerates `results/b_spatial_audit_figure.png`. |
| `data/Facilities_B_handoff.csv` | Member B's 99 cleaned records (53 `Tennis Court` + 46 `Swimming Pool`) in the 5-column handoff format. |
| `data/Tennis_Courts_cleaned.csv` <br> `data/Swimming_Pools_cleaned.csv` | Detailed cleaned tables for Part B retaining source IDs, coordinate methods, geometry-vs-attribute offsets, and district checks. |
| `data/Facilities_master_781.csv` | Consolidated 5-column table across all 8 categories (781 records: A=422, B=99, C=111, D=149) using a single canonical category vocabulary. |
| `data/Facilities_master_781_audited.csv` | Full 781-row audit table with `facility_id` (1..781), `member_owner`, `provider_district`, `spatial_district_st_covers`, `distance_to_nearest_polygon_m`, and `spatial_match_status`. |
| `sql/01_create_facilities_table.sql` | Non-destructive (`CREATE TABLE IF NOT EXISTS`) DDL for `public.facilities` with single-vocabulary `CHECK` constraint and dual GiST indexes. |
| `sql/02_load_facilities_781.sql` | Safe load script for all 781 records: inserts into an empty table, or verifies all 7 columns (`facility_id`, `facility_type`, `facility_name`, `address`, `latitude`, `longitude`, `geom`) if non-empty and halts on any discrepancy. |
| `sql/03_validate_facilities_and_spatial_check.sql` | PostGIS verification queries checking row counts, SRID 4326, coordinate consistency, and `ST_Covers` against `public.hk_admin`. |
| `sql/04_team_integration_and_views.sql` | Creates `public.v_facilities_with_district` (using `LEFT JOIN LATERAL` so all 781 rows are preserved without altering source coordinates) and maps `d_project.facilities_input` to `public.facilities`. |
| `sql/05_q3_q4_district_queries_for_e.sql` | Reference SQL queries for Task 3 Question 3 (ordered by count) and Question 4 (ordered by per-capita count), retaining zero-facility districts. |
| `results/all_781_spatial_audit_issues.csv` | Programmatically verified audit log of the 2 coastal park points outside polygons and 4 provider-vs-polygon district differences (100% coordinate-matched to `Facilities_master_781_audited.csv`). |
| `results/d_queries_on_781_comparison.csv` | Comparison of Member D's Q1 and Q2 outputs at all four study points on the 781-row master table versus D's 775-row snapshot. |
| `results/e_q3_district_counts_ranked.csv` <br> `results/e_q4_district_per_capita_ranked.csv` | Reference tables for Member E sorted separately by facility count (Q3) and by per-capita facility count (Q4) across all 18 districts. |
| `presentation/B_Slides_and_Script.md` | Four slide outlines, a timed 338-word English script (3 minutes), and Q&A preparation for Member B. |
| `docs/B_Report_Section.md` | English report contribution for Task 1 and Task 2. |

## 2. Reproducing All Outputs from Source Data

All raw snapshots (`data/source/`) and upstream team handoffs (`data/upstream_handoffs/`) are bundled inside this archive. From the `B_Deliverables` directory, run:

```bash
python3 scripts/clean_and_consolidate_b.py
python3 scripts/make_figures_b.py
```

The script uses relative paths only (`Path(__file__).resolve().parents[1]`), verifies input SHA-256 hashes, and does not delete directories or overwrite raw source files.

## 3. Running the SQL in PostgreSQL/PostGIS

1. Test in a dedicated database or after Member C's `public.hk_admin` and `public.census` tables have been created.
2. Execute in order:
   - `sql/01_create_facilities_table.sql`
   - `sql/02_load_facilities_781.sql`
   - `sql/03_validate_facilities_and_spatial_check.sql`
   - `sql/04_team_integration_and_views.sql`
   - `sql/05_q3_q4_district_queries_for_e.sql`
