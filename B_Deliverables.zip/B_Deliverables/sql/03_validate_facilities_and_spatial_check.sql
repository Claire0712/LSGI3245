-- ============================================================================
-- LSGI3245 Group Project - Member B Deliverable
-- File: 03_validate_facilities_and_spatial_check.sql
-- Purpose: Attribute and spatial verification of public.facilities against
--          public.hk_admin (Task 2 location verification).
-- ============================================================================

-- 1. Total record count and breakdown across all 8 categories (Expected: 781 total)
SELECT
    facility_type,
    count(*) AS facility_count
FROM public.facilities
GROUP BY ROLLUP (facility_type)
ORDER BY facility_type NULLS LAST;

-- 2. Verify exactly 8 distinct categories and valid Point geometries in EPSG:4326
SELECT
    count(*) AS total_rows,
    count(DISTINCT facility_type) AS distinct_type_count,
    count(*) FILTER (WHERE geom IS NOT NULL AND ST_IsValid(geom) AND NOT ST_IsEmpty(geom)) AS valid_geom_rows,
    count(*) FILTER (WHERE GeometryType(geom) = 'POINT' AND ST_SRID(geom) = 4326) AS valid_point_srid_4326,
    count(*) FILTER (
        WHERE abs(ST_X(geom) - longitude) < 1e-12
          AND abs(ST_Y(geom) - latitude) < 1e-12
    ) AS coord_consistency_rows
FROM public.facilities;

-- 3. Spatial coverage check with public.hk_admin using strict ST_Covers
--    Expected: 779 strictly covered; 2 coastal park points in Member D's dataset
--    lie 0.38 m and 10.95 m outside the HKDistrict18 polygon boundary.
SELECT
    count(*) AS total_facilities,
    count(*) FILTER (
        WHERE EXISTS (
            SELECT 1 FROM public.hk_admin AS a WHERE ST_Covers(a.geom, f.geom)
        )
    ) AS strictly_covered_by_hk_admin,
    count(*) FILTER (
        WHERE NOT EXISTS (
            SELECT 1 FROM public.hk_admin AS a WHERE ST_Covers(a.geom, f.geom)
        )
    ) AS outside_polygon_boundary
FROM public.facilities AS f;

-- 4. Inspect the 2 coastal facilities not covered by strict ST_Covers and measure
--    their exact spheroidal distance (in metres) to the nearest HK_Admin polygon.
--    Original coordinates are preserved unchanged.
SELECT
    f.facility_id,
    f.facility_type,
    f.facility_name,
    f.address,
    round(f.latitude::numeric, 7) AS latitude,
    round(f.longitude::numeric, 7) AS longitude,
    nearest_d.district_name AS nearest_admin_district,
    round(nearest_d.dist_m::numeric, 2) AS distance_to_polygon_m
FROM public.facilities AS f
LEFT JOIN LATERAL (
    SELECT
        a.district_name,
        ST_Distance(f.geom::geography, a.geom::geography, true) AS dist_m
    FROM public.hk_admin AS a
    ORDER BY ST_Distance(f.geom::geography, a.geom::geography, true)
    LIMIT 1
) AS nearest_d ON true
WHERE NOT EXISTS (
    SELECT 1 FROM public.hk_admin AS a WHERE ST_Covers(a.geom, f.geom)
)
ORDER BY f.facility_id;
