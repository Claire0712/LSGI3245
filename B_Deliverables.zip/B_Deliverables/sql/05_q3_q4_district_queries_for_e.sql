-- ============================================================================
-- LSGI3245 Group Project - Member B Deliverable
-- File: 05_q3_q4_district_queries_for_e.sql
-- Purpose: Reference SQL queries for Task 3 Question 3 (ordered by facility count)
--          and Question 4 (ordered by per-capita facility count), retaining
--          zero-facility districts via LEFT JOIN.
-- ============================================================================

-- Q3: For a given facility type (e.g., 'Tennis Court'), order the 18 administrative
--     districts in Hong Kong by the NUMBER of such facilities (strict ST_Covers).
SELECT
    a.district_name,
    count(f.facility_id) AS facility_count
FROM public.hk_admin AS a
LEFT JOIN public.facilities AS f
  ON f.facility_type = 'Tennis Court'
 AND ST_Covers(a.geom, f.geom)
GROUP BY a.district_name
ORDER BY facility_count DESC, a.district_name ASC;

-- Q4 (Strict ST_Covers): Order all 18 administrative districts by PER CAPITA
--     facility count, using LEFT JOIN public.census and NULLS LAST so no district
--     is ever dropped even if population is missing or zero.
SELECT
    a.district_name,
    c.population,
    count(f.facility_id) AS facility_count,
    round((count(f.facility_id)::numeric / NULLIF(c.population, 0)), 8) AS facilities_per_capita,
    round((count(f.facility_id) * 100000.0 / NULLIF(c.population, 0)), 3) AS facilities_per_100k_people
FROM public.hk_admin AS a
LEFT JOIN public.census AS c
  ON c.district_name = a.district_name
LEFT JOIN public.facilities AS f
  ON f.facility_type = 'Tennis Court'
 AND ST_Covers(a.geom, f.geom)
GROUP BY a.district_name, c.population
ORDER BY facilities_per_capita DESC NULLS LAST, a.district_name ASC;

-- Q4 (15m Coastal Tolerance option via v_facilities_with_district):
SELECT
    a.district_name,
    c.population,
    count(v.facility_id) AS facility_count_with_15m_tolerance,
    round((count(v.facility_id)::numeric / NULLIF(c.population, 0)), 8) AS facilities_per_capita,
    round((count(v.facility_id) * 100000.0 / NULLIF(c.population, 0)), 3) AS facilities_per_100k_people
FROM public.hk_admin AS a
LEFT JOIN public.census AS c
  ON c.district_name = a.district_name
LEFT JOIN public.v_facilities_with_district AS v
  ON v.facility_type = 'Tennis Court'
 AND v.district_name_with_15m_tolerance = a.district_name
GROUP BY a.district_name, c.population
ORDER BY facilities_per_capita DESC NULLS LAST, a.district_name ASC;
