-- ============================================================================
-- LSGI3245 Group Project - Member B Deliverable
-- File: 04_team_integration_and_views.sql
-- Purpose:
--   1. Create public.v_facilities_with_district using LEFT JOIN LATERAL so
--      every row in public.facilities is guaranteed to be retained (never
--      dropped even if outside polygons), while preserving original point
--      coordinates unchanged and explicitly labelling strict vs tolerance matches.
--   2. Connect Member D's d_project.facilities_input view to public.facilities
--      with a 1-to-1 mapping to D's plural category names.
-- ============================================================================

CREATE OR REPLACE VIEW public.v_facilities_with_district AS
SELECT
    f.facility_id,
    f.facility_type,
    CASE f.facility_type
        WHEN 'Badminton Court' THEN 'Badminton Courts'
        WHEN 'Basketball Court' THEN 'Basketball Courts'
        WHEN 'Tennis Court' THEN 'Tennis Courts'
        WHEN 'Country Park' THEN 'Country Parks'
        WHEN 'Fitness Room' THEN 'Fitness Rooms'
        WHEN 'Parks, Zoos and Gardens' THEN 'Parks, Zoos and Gardens'
        WHEN 'Sports Ground' THEN 'Sports Grounds'
        WHEN 'Swimming Pool' THEN 'Swimming Pools'
        ELSE f.facility_type
    END AS facility_type_plural,
    f.facility_name,
    f.address,
    f.latitude,
    f.longitude,
    f.geom,
    strict_admin.district_name AS district_name_strict,
    COALESCE(strict_admin.district_name, tol_admin.district_name, 'Unassigned') AS district_name_with_15m_tolerance,
    CASE
        WHEN strict_admin.district_name IS NOT NULL THEN 'ST_Covers_Exact'
        WHEN tol_admin.district_name IS NOT NULL THEN 'Tolerance_15m_Estimate'
        ELSE 'Unassigned'
    END AS district_match_method,
    CASE
        WHEN strict_admin.district_name IS NOT NULL THEN 0.000
        WHEN tol_admin.district_name IS NOT NULL THEN round(tol_admin.dist_m::numeric, 3)
        ELSE NULL
    END AS distance_to_polygon_m
FROM public.facilities AS f
LEFT JOIN LATERAL (
    SELECT a.district_name
    FROM public.hk_admin AS a
    WHERE ST_Covers(a.geom, f.geom)
    ORDER BY a.district_id
    LIMIT 1
) AS strict_admin ON true
LEFT JOIN LATERAL (
    SELECT
        a.district_name,
        ST_Distance(f.geom::geography, a.geom::geography, true) AS dist_m
    FROM public.hk_admin AS a
    WHERE ST_DWithin(f.geom::geography, a.geom::geography, 15.0, true)
    ORDER BY ST_Distance(f.geom::geography, a.geom::geography, true), a.district_id
    LIMIT 1
) AS tol_admin ON strict_admin.district_name IS NULL;

-- Connect Member D's d_project.facilities_input view to the unified table
-- (Executes automatically if schema d_project exists)
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.schemata WHERE schema_name = 'd_project') THEN
        EXECUTE $view$
            CREATE OR REPLACE VIEW d_project.facilities_input AS
            SELECT
                lpad(facility_id::text, 4, '0') AS facility_id,
                facility_name::text AS facility_name,
                facility_type_plural::text AS facility_type,
                upper(
                    CASE district_name_with_15m_tolerance
                        WHEN 'Central and Western' THEN 'CENTRAL & WESTERN'
                        ELSE district_name_with_15m_tolerance
                    END
                )::text AS district,
                address::text AS address,
                geom::geometry(Point, 4326) AS geom
            FROM public.v_facilities_with_district;
        $view$;
    END IF;
END $$;
