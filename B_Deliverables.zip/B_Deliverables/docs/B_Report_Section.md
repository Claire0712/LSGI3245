# Part B — Written Report Contribution (Task 1 Data Cleaning & Task 2 `Facilities` Implementation)

LSGI3245 Geospatial Database Management and Design | 2026/27 Semester 1

This document provides the English report text and summary tables for Member B's allocation: cleaning the Tennis Courts and Swimming Pools datasets, harmonizing all eight facility categories into a unified relational schema, implementing `public.facilities` in PostgreSQL/PostGIS, and validating facility locations against the administrative district polygons (`public.hk_admin`).

## 1. Data Cleaning and Cross-Team Standardization (Task 1)

### 1.1 Cleaning Tennis Courts and Swimming Pools
For Member B's allocated categories, **53 Tennis Court** records (`lcsd_rcd_1629267205215_84141`) and **46 Swimming Pool** records (`lcsd_rcd_1634540558875_77434`) were processed from the English-column snapshots verified by SHA-256 checksums against `data/source_manifest_B.json`. Both datasets underwent four deterministic preprocessing steps:

1. **Attribute Selection and Text Normalization:** Non-spatial administrative metadata, Chinese-language columns, HTML tags/entities, and redundant whitespace were removed. Every record was verified to contain a non-empty English facility name (`facility_name`) and address (`address`).
2. **Coordinate Reference System (CRS) Harmonization:** The raw datasets used different coordinate representations. While the Tennis Courts snapshot provided WGS84 decimal geometry coordinates (`GeometryLongitude`, `GeometryLatitude`), the Swimming Pools snapshot stored its point geometry in the Hong Kong 1980 Grid System (`EPSG:2326` `GeometryEasting` and `GeometryNorthing`). Using `pyproj` (`EPSG:2326` to `EPSG:4326`), all Swimming Pool geometry coordinates were transformed into WGS84 decimal degrees so that all records share a single datum (`EPSG:4326`).
3. **Coordinate Provenance Audit (5 m Review Threshold):** Both datasets include both GIS geometry columns and tabular `LATITUDE`/`LONGITUDE` attributes. Spheroidal distance comparisons on the WGS84 ellipsoid identified offsets exceeding 5 m in **23 of 53 Tennis Courts** (maximum offset: **25.60 m** at *North Kwai Chung Tang Shiu Kin Sports Centre*) and **6 of 46 Swimming Pools** (maximum offset: **54.31 m** at *Kowloon Park Swimming Pool* and **53.34 m** at *Tung Chung Swimming Pool*). Following the group's provenance rule, the source GIS geometry coordinates were retained and all offsets were logged in `results/b_quality_issues.csv` rather than deleting valid public venues.
4. **Deduplication and Envelope Screening:** Records were screened for identical full source rows and checked against the Hong Kong bounding envelope (22.13°–22.57° N, 113.80°–114.50° E). Zero rows were rejected or removed as exact duplicates across both datasets, yielding **99 cleaned records** in `data/Facilities_B_handoff.csv`.

### 1.2 Harmonizing All Eight Facility Categories (n = 781)
To prevent duplicate category counts in `COUNT(DISTINCT facility_type)` queries, all four team handoffs (Members A, B, C, and D) were standardized into a single canonical five-column structure (`facility_type, facility_name, address, latitude, longitude`) using a single canonical category vocabulary:

| Member | Canonical `facility_type` | Source Format & Coordinate Method | Raw Rows | Cleaned Rows | Duplicates Removed | Exact `ST_Covers` Match |
| :---: | :--- | :--- | :---: | :---: | :---: | :---: |
| **A** | `Badminton Court` | CSDI CSV (`EPSG:4326` geometry) | 116 | 116 | 0 | 116 (100%) |
| **A** | `Basketball Court` | CSDI CSV (`EPSG:4326` geometry) | 306 | 306 | 0 | 306 (100%) |
| **B** | `Tennis Court` | CSDI CSV (`EPSG:4326` geometry) | 53 | 53 | 0 | 53 (100%) |
| **B** | `Swimming Pool` | CSDI CSV (`EPSG:2326` to `EPSG:4326`) | 46 | 46 | 0 | 46 (100%) |
| **C** | `Fitness Room` | LCSD JSON (`DMS` to `EPSG:4326`) | 87 | 86 | 1 | 86 (100%) |
| **C** | `Sports Ground` | LCSD JSON (`DMS` to `EPSG:4326`) | 25 | 25 | 0 | 25 (100%) |
| **D** | `Country Park` | AFCD CSV (`EPSG:2326` to `EPSG:4326`) | 25 | 25 | 0 | 25 (100%) |
| **D** | `Parks, Zoos and Gardens` | LCSD CSV (`EPSG:2326` to `EPSG:4326`) | 124 | 124 | 0 | 122 (98.4%) |
| **Total** | **8 Canonical Categories** | **Unified `EPSG:4326` Point** | **782** | **781** | **1** | **779 (99.74%)** |

*Note on total record count (781 vs. 775 demonstration snapshot):* Member C cleaned Fitness Rooms from the official LCSD JSON feed (87 raw rows, 1 duplicate removed = 86 unique records, with 5 documented DMS coordinate corrections), whereas Member D's preliminary demonstration snapshot used a converted GDB table with 80 Fitness Rooms. All other seven categories have identical record counts (775 - 80 + 86 = 781).

## 2. `Facilities` Table Implementation and Spatial Validation (Task 2)

### 2.1 Relational and PostGIS Implementation (`public.facilities`)
In PostgreSQL/PostGIS (`sql/01_create_facilities_table.sql` and `sql/02_load_facilities_781.sql`), `public.facilities` is created non-destructively (`CREATE TABLE IF NOT EXISTS`) and populated via a verified staging-table load (`02_load_facilities_781.sql`) that inserts into an empty table or verifies all seven columns across all 781 rows before halting on any mismatch, preserving dependent views without destructive overwrites. Each record stores `facility_id` (1 to 781), `facility_type` (constrained by a strict single-vocabulary `CHECK` constraint), `facility_name`, `address`, `latitude`, `longitude`, and `geom geometry(Point, 4326) NOT NULL` constructed via `ST_SetSRID(ST_MakePoint(longitude, latitude), 4326)`. Two spatial GiST indexes support downstream queries:
- `facilities_geom_gix ON public.facilities USING gist (geom)` for polygon containment joins (`ST_Covers`) with `public.hk_admin`.
- `facilities_geography_gix ON public.facilities USING gist ((geom::geography))` for spheroidal metre-based proximity queries (`ST_Distance` and `ST_DWithin`).

### 2.2 Spatial Location Verification Against `HK_Admin`
Checking all 781 facility points against the 18 administrative district polygons in `public.hk_admin` (`sql/03_validate_facilities_and_spatial_check.sql` and `results/all_781_spatial_audit_issues.csv`) established two sets of spatial findings:

| `facility_id` | Member | `facility_type` | `facility_name` | Latitude | Longitude | Audit Category | Provider District | `HK_Admin` `ST_Covers` | Nearest Polygon Distance |
| :---: | :---: | :--- | :--- | :---: | :---: | :--- | :--- | :--- | :---: |
| **228** | A | `Basketball Court` | Lei Yue Mun Basketball Court | 22.2881000 | 114.2373000 | `PROVIDER_VS_POLYGON_DISTRICT_DIFF` | `LEI YUE MUN` | `Kwun Tong` | 0.000 m |
| **402** | A | `Basketball Court` | Victoria Park | 22.2826000 | 114.1882000 | `PROVIDER_VS_POLYGON_DISTRICT_DIFF` | `Wan Chai` | `Eastern` | 0.000 m |
| **471** | B | `Tennis Court` | Victoria Park | 22.2826000 | 114.1882000 | `PROVIDER_VS_POLYGON_DISTRICT_DIFF` | `Wan Chai` | `Eastern` | 0.000 m |
| **601** | D | `Parks, Zoos and Gardens` | East Coast Park (Phase 1) | 22.2879294 | 114.1891845 | `OUTSIDE_POLYGON_COASTAL` | `Wan Chai` | `None` | 10.946 m (`Eastern`) |
| **687** | D | `Parks, Zoos and Gardens` | Tsing Bik Sitting-out Area | 22.3772762 | 113.9803686 | `OUTSIDE_POLYGON_COASTAL` | `Tuen Mun` | `None` | 0.380 m (`Tuen Mun`) |
| **779** | B | `Swimming Pool` | Victoria Park Swimming Pool | 22.2833358 | 114.1904757 | `PROVIDER_VS_POLYGON_DISTRICT_DIFF` | `Wan Chai` | `Eastern` | 0.000 m |

1. **Coastal Points Outside Polygon Boundaries (`facility_id` 601 and 687):** Exactly **779 of 781 points (99.74%)** are strictly covered by one `public.hk_admin` polygon (`ST_Covers`). Two waterfront park points in Member D's dataset—*Tsing Bik Sitting-out Area* (`22.3772762, 113.9803686`) and *East Coast Park (Phase 1)* (`22.2879294, 114.1891845`)—lie **0.380 m** and **10.946 m** outside the nearest polygon boundaries (`Tuen Mun` and `Eastern`, respectively). Original source coordinates are preserved unchanged in `public.facilities` so proximity calculations are not distorted. In `sql/04_team_integration_and_views.sql`, `public.v_facilities_with_district` uses a `LEFT JOIN LATERAL` structure that retains all 781 rows and explicitly distinguishes `ST_Covers_Exact` (779 rows) from `Tolerance_15m_Estimate` (2 rows).
2. **Provider Attribute vs. Polygon Discrepancies (`facility_id` 228, 402, 471, and 779):** Three records at *Victoria Park* (`facility_id` 402, 471, and 779) carry the provider text label `Wan Chai` while falling spatially inside the `Eastern` polygon of the course-supplied `HKDistrict18` shapefile, and *Lei Yue Mun Basketball Court* (`facility_id` 228) carries the locality label `LEI YUE MUN` while falling inside `Kwun Tong`. The cause of the provider-versus-boundary discrepancy is not independently verified from the bundled files; original coordinates are retained and documented for transparent district-level interpretation.
